"""
Pharmacophore Feature Definitions, Tolerances, and Model Representation.

Defines:
- Standard CADD 3D pharmacophore feature types (HBD, HBA, AROM, HYD, POS, NEG, EXCL)
- Directional vectors (H-bond orientation, aromatic ring normals)
- Spatial tolerance spheres
- PyMOL script (.pml) and JSON serialization for visualization and sharing
"""

from __future__ import annotations
import math
import json
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import List, Dict, Tuple, Optional, Any


class FeatureType(str, Enum):
    """Core pharmacophoric interaction types."""
    HBD = "HBD"                 # Hydrogen Bond Donor
    HBA = "HBA"                 # Hydrogen Bond Acceptor
    AROMATIC = "AROMATIC"       # Aromatic Ring Centroid
    HYDROPHOBIC = "HYDROPHOBIC" # Lipophilic / Hydrophobic Center
    POS_IONIZABLE = "POS"       # Positive Ionizable / Cation
    NEG_IONIZABLE = "NEG"       # Negative Ionizable / Anion
    EXCLUDED_VOLUME = "EXCL"    # Receptor Steric Excluded Volume Boundary


# Canonical color codes (RGB 0-1) for PyMOL / 3Dmol visualization
FEATURE_COLORS: Dict[FeatureType, Tuple[float, float, float]] = {
    FeatureType.HBD: (0.2, 0.4, 0.9),           # Blue
    FeatureType.HBA: (0.9, 0.2, 0.2),           # Red
    FeatureType.AROMATIC: (0.9, 0.5, 0.1),      # Orange
    FeatureType.HYDROPHOBIC: (0.2, 0.8, 0.2),   # Green
    FeatureType.POS_IONIZABLE: (0.3, 0.8, 0.9), # Cyan
    FeatureType.NEG_IONIZABLE: (0.8, 0.2, 0.8), # Magenta
    FeatureType.EXCLUDED_VOLUME: (0.5, 0.5, 0.5)# Grey
}


@dataclass
class PharmacophoreFeature:
    """A 3D spatial pharmacophoric feature with tolerance sphere and optional direction vector."""
    feature_type: FeatureType
    x: float
    y: float
    z: float
    tolerance: float = 1.2
    vector: Optional[Tuple[float, float, float]] = None
    weight: float = 1.0
    label: str = ""
    residue_partner: str = ""

    @property
    def coords(self) -> Tuple[float, float, float]:
        return (self.x, self.y, self.z)

    def distance_to(self, point: Tuple[float, float, float]) -> float:
        dx = self.x - point[0]
        dy = self.y - point[1]
        dz = self.z - point[2]
        return math.sqrt(dx * dx + dy * dy + dz * dz)

    def is_point_within_tolerance(self, point: Tuple[float, float, float]) -> bool:
        return self.distance_to(point) <= self.tolerance


@dataclass
class PharmacophoreModel:
    """A collection of pharmacophoric features representing a bioactivity hypothesis."""
    name: str
    features: List[PharmacophoreFeature] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def num_features(self) -> int:
        return len(self.features)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "metadata": self.metadata,
            "features": [
                {
                    "type": f.feature_type.value,
                    "x": f.x,
                    "y": f.y,
                    "z": f.z,
                    "tolerance": f.tolerance,
                    "vector": f.vector,
                    "weight": f.weight,
                    "label": f.label,
                    "residue_partner": f.residue_partner,
                }
                for f in self.features
            ],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> PharmacophoreModel:
        feats = [
            PharmacophoreFeature(
                feature_type=FeatureType(item["type"]),
                x=float(item["x"]),
                y=float(item["y"]),
                z=float(item["z"]),
                tolerance=float(item.get("tolerance", 1.2)),
                vector=item.get("vector"),
                weight=float(item.get("weight", 1.0)),
                label=item.get("label", ""),
                residue_partner=item.get("residue_partner", ""),
            )
            for item in data.get("features", [])
        ]
        return cls(name=data.get("name", "Model"), features=feats, metadata=data.get("metadata", {}))

    def save_json(self, filepath: str) -> None:
        """Save model to JSON file."""
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load_json(cls, filepath: str) -> PharmacophoreModel:
        """Load model from JSON file."""
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)

    def export_pymol_script(self, filepath: str) -> None:
        """Generate an executable PyMOL .pml script visualizing features as CGO transparent spheres."""
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(f"# PyMOL Visualization Script for Pharmacophore: {self.name}\n")
            f.write("from pymol.cgo import *\nfrom pymol import cmd\n\n")
            f.write("obj = []\n")
            for idx, feat in enumerate(self.features):
                r, g, b = FEATURE_COLORS.get(feat.feature_type, (0.7, 0.7, 0.7))
                f.write(f"# Feature {idx+1}: {feat.feature_type.value} ({feat.label})\n")
                f.write(f"obj.extend([COLOR, {r:.3f}, {g:.3f}, {b:.3f}])\n")
                f.write(f"obj.extend([SPHERE, {feat.x:.3f}, {feat.y:.3f}, {feat.z:.3f}, {feat.tolerance:.3f}])\n")
                if feat.vector:
                    vx, vy, vz = feat.vector
                    end_x = feat.x + vx * 1.5
                    end_y = feat.y + vy * 1.5
                    end_z = feat.z + vz * 1.5
                    f.write(f"obj.extend([CYLINDER, {feat.x:.3f}, {feat.y:.3f}, {feat.z:.3f}, {end_x:.3f}, {end_y:.3f}, {end_z:.3f}, 0.15, {r:.3f}, {g:.3f}, {b:.3f}, {r:.3f}, {g:.3f}, {b:.3f}])\n")
            f.write(f"cmd.load_cgo(obj, '{self.name}_features')\n")
            f.write("cmd.set('cgo_transparency', 0.45)\n")
            f.write("cmd.zoom()\n")
