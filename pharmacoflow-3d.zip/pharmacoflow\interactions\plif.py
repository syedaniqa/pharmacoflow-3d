"""
Protein-Ligand Interaction Fingerprinting (PLIF) Engine.

Transforms 3D non-covalent contact networks into binary and count fingerprints:
- Per-residue 7-bit interaction encoding
- PLIF Tanimoto/Jaccard similarity scoring against bioactive reference complexes
- Trajectory and ensemble interaction persistence frequency calculation
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Set
from pharmacoflow.core.structures import Molecule3D, ProteinComplex
from pharmacoflow.interactions.contacts import (
    ContactDetector,
    ContactEvent,
    InteractionType,
)


@dataclass
class InteractionFingerprint:
    """A structured interaction fingerprint representation."""
    ligand_name: str
    residue_ids: List[str]
    bit_vector: List[int]  # Binary representation (0 or 1)
    event_counts: Dict[str, Dict[str, int]] = field(default_factory=dict)
    contacts: List[ContactEvent] = field(default_factory=list)

    @property
    def on_bits_count(self) -> int:
        return sum(self.bit_vector)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ligand_name": self.ligand_name,
            "on_bits": self.on_bits_count,
            "total_bits": len(self.bit_vector),
            "residue_profiles": self.event_counts,
        }


def compute_plif(
    receptor: ProteinComplex,
    ligand: Molecule3D,
    fixed_residue_ids: Optional[List[str]] = None,
    detector: Optional[ContactDetector] = None,
) -> InteractionFingerprint:
    """
    Generate a 1D binary Protein-Ligand Interaction Fingerprint (PLIF).
    Each residue is represented by 7 distinct interaction bits.
    """
    if detector is None:
        detector = ContactDetector()

    contacts = detector.detect_contacts(receptor, ligand)

    # If fixed residue order is not supplied, use sorted unique residues present in contacts
    if fixed_residue_ids is None:
        unique_res = sorted(list({c.residue_id for c in contacts}))
        if not unique_res:
            # Fallback: pocket residues
            pocket = receptor.get_binding_pocket(ligand, cutoff_radius=5.0)
            unique_res = sorted([f"{r.chain}:{r.name}{r.resnum}" for r in pocket])
        fixed_residue_ids = unique_res

    # 7 standard bit indices per residue
    type_order = [
        InteractionType.HBOND_DONOR,
        InteractionType.HBOND_ACCEPTOR,
        InteractionType.SALT_BRIDGE,
        InteractionType.PI_STACKING,
        InteractionType.CATION_PI,
        InteractionType.HALOGEN_BOND,
        InteractionType.HYDROPHOBIC,
    ]

    event_counts: Dict[str, Dict[str, int]] = {r: {t.value: 0 for t in type_order} for r in fixed_residue_ids}

    for c in contacts:
        if c.residue_id in event_counts:
            event_counts[c.residue_id][c.interaction_type.value] += 1

    bits: List[int] = []
    for r in fixed_residue_ids:
        for t in type_order:
            val = event_counts[r][t.value]
            bits.append(1 if val > 0 else 0)

    return InteractionFingerprint(
        ligand_name=ligand.name,
        residue_ids=list(fixed_residue_ids),
        bit_vector=bits,
        event_counts=event_counts,
        contacts=contacts,
    )


def plif_tanimoto(fp1: InteractionFingerprint, fp2: InteractionFingerprint) -> float:
    """
    Calculate Tanimoto (Jaccard) coefficient between two PLIF bit-vectors:
    Tc = (A & B) / (A + B - (A & B))
    """
    v1 = fp1.bit_vector
    v2 = fp2.bit_vector
    if len(v1) != len(v2) or len(v1) == 0:
        return 0.0

    a_and_b = sum(1 for b1, b2 in zip(v1, v2) if b1 == 1 and b2 == 1)
    a_count = sum(v1)
    b_count = sum(v2)

    denominator = a_count + b_count - a_and_b
    if denominator == 0:
        return 1.0 if a_count == b_count else 0.0

    return round(a_and_b / denominator, 4)
