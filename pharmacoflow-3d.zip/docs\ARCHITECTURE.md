# Scientific Architecture & Theoretical Foundations

`PharmacoFlow-3D` is an automated computational drug design platform engineered to overcome the high false-positive rate (~85%) of static rigid receptor docking in High-Throughput Virtual Screening (HTVS). It achieves this by coupling **Structure-Guided 3D Pharmacophores**, **Protein-Ligand Interaction Fingerprints (PLIF)**, and **Pfizer CNS Multiparameter Optimization (CNS-MPO)** into a unified multi-objective consensus engine.

```
                              ┌────────────────────────────────────────┐
                              │  Macromolecular Target Complex (PDB)   │
                              │      + Bioactive Reference (SDF)       │
                              └───────────────────┬────────────────────┘
                                                  │
                      ┌───────────────────────────┴───────────────────────────┐
                      ▼                                                       ▼
        ┌───────────────────────────┐                           ┌───────────────────────────┐
        │   Active Site Analysis    │                           │  Receptor-Guided 3D       │
        │   & Pocket Extraction     │                           │  Pharmacophore Derivation │
        └─────────────┬─────────────┘                           └─────────────┬─────────────┘
                      │                                                       │
                      ▼                                                       ▼
        ┌───────────────────────────┐                           ┌───────────────────────────┐
        │  PLIF Contact Profiler    │                           │  Spatial Tolerance Match  │
        │  (7-Bit Per Pocket Res)   │                           │  (HBD, HBA, ARO, HYD, +/-)│
        └─────────────┬─────────────┘                           └─────────────┬─────────────┘
                      │                                                       │
                      └───────────────────────────┬───────────────────────────┘
                                                  │
                                                  ▼
                                ┌───────────────────────────────────┐
                                │   Candidate Library Screening     │
                                │   (Multi-Conformer Poses / Vina)  │
                                └─────────────────┬─────────────────┘
                                                  │
                                                  ▼
                                ┌───────────────────────────────────┐
                                │   Pfizer CNS-MPO & Druggability   │
                                │   (MW, ClogP, ClogD, TPSA, pKa)   │
                                └─────────────────┬─────────────────┘
                                                  │
                                                  ▼
                                ┌───────────────────────────────────┐
                                │  Consensus Rank Aggregator        │
                                │  • Standardized Z-Score Ranking   │
                                │  • Borda Count Summation          │
                                │  • Pareto Non-Dominated Frontier  │
                                └─────────────────┬─────────────────┘
                                                  │
                                                  ▼
                                ┌───────────────────────────────────┐
                                │   Interactive 3D WebGL Dashboard  │
                                │   CSV / JSON / PyMOL Artifacts    │
                                └───────────────────────────────────┘
```

---

## 1. 3D Pharmacophore Feature Perception & Overlap Geometry

A 3D pharmacophore hypothesis $\mathcal{H} = \{ F_1, F_2, \dots, F_m \}$ is a set of spatial interaction features, where each feature $F_i$ is defined by:
- A centroid position $\mathbf{x}_i \in \mathbb{R}^3$.
- A spatial tolerance radius $r_{\text{tol}, i} \in [1.0, 1.8]$ \AA.
- A functional feature type $\tau_i \in \{ \text{HBD}, \text{HBA}, \text{AROMATIC}, \text{HYDROPHOBIC}, \text{POS}, \text{NEG} \}$.
- An optional directional orientation vector $\mathbf{v}_i \in \mathbb{R}^3$, where $\|\mathbf{v}_i\| = 1$.
- An importance weight $w_i \in \mathbb{R}^+$.

### Spatial Matching & Fitness Function
For a candidate ligand conformation $L$ with mapped feature coordinates $\mathbf{y}_i$, the spatial distance deviation is:
$$d_i = \| \mathbf{x}_i - \mathbf{y}_i \|_2$$

A candidate feature matches if $d_i \le r_{\text{tol}, i}$. The normalized spatial fitness score $S(L) \in [0, 1]$ is computed using a parabolic distance penalty:
$$S(L) = \frac{1}{\sum_{i=1}^m w_i} \sum_{i \in \text{matched}} w_i \cdot \max\left(0, 1 - \frac{d_i^2}{r_{\text{tol}, i}^2}\right)$$

---

## 2. Protein-Ligand Interaction Fingerprints (PLIF)

For each active site residue $R_k$ within $5.5$ \AA\ of the ligand binding envelope, `PharmacoFlow-3D` evaluates 7 discrete non-covalent interaction modalities:
1. **$b_1$ (HBOND_DONOR):** Ligand heteroatom ($N, O$) donates a proton to a receptor backbone or sidechain carbonyl/carboxylate ($d \le 3.5$ \AA).
2. **$b_2$ (HBOND_ACCEPTOR):** Receptor amine/hydroxyl donates to ligand electronegative atom ($d \le 3.5$ \AA).
3. **$b_3$ (SALT_BRIDGE_CAT):** Positively charged residue (Arg, Lys, His) paired with ligand anion ($d \le 4.0$ \AA).
4. **$b_4$ (SALT_BRIDGE_ANI):** Negatively charged residue (Asp, Glu) paired with ligand cation ($d \le 4.0$ \AA).
5. **$b_5$ (PI_STACKING):** Aromatic residue (Phe, Tyr, Trp, His) interacting with ligand $\pi$-system ($d \le 4.5$ \AA).
6. **$b_6$ (CATION_PI):** Basic center interacting with aromatic centroid ($d \le 4.5$ \AA).
7. **$b_7$ (HYDROPHOBIC):** Aliphatic or aromatic carbon-carbon contact ($d \le 4.0$ \AA).

The composite interaction fingerprint $\mathbf{B} \in \{0, 1\}^{7 \times K}$ has length $7K$, where $K$ is the number of pocket residues.

### PLIF Tanimoto Similarity
The interaction profile similarity between a candidate pose $L$ and the co-crystallized bioactive reference $R$ is calculated via the Jaccard/Tanimoto metric:
$$T_c(\mathbf{B}_L, \mathbf{B}_R) = \frac{\sum_{j=1}^{7K} (\mathbf{B}_{L, j} \land \mathbf{B}_{R, j})}{\sum_{j=1}^{7K} \mathbf{B}_{L, j} + \sum_{j=1}^{7K} \mathbf{B}_{R, j} - \sum_{j=1}^{7K} (\mathbf{B}_{L, j} \land \mathbf{B}_{R, j})}$$

---

## 3. Pfizer CNS Multiparameter Optimization (CNS-MPO)

Virtual screening against neurodegenerative targets frequently produces false-positive leads that cannot cross the blood-brain barrier (BBB). `PharmacoFlow-3D` incorporates the Pfizer CNS-MPO algorithm (*Wager et al., ACS Chem. Neurosci. 2010, 2016*):

$$\text{CNS-MPO} = \sum_{p=1}^6 D_p(x_p) \in [0.0, 6.0]$$

| Parameter ($x_p$) | Optimal Range | Desirability Formulation $D_p(x_p)$ |
| :--- | :--- | :--- |
| **ClogP** | $\le 3.0$ | Monotonic decreasing: $1.0$ for $x \le 3.0$, drops to $0.0$ at $x = 5.0$ |
| **ClogD$_{7.4}$** | $\le 2.0$ | Monotonic decreasing: $1.0$ for $x \le 2.0$, drops to $0.0$ at $x = 4.0$ |
| **MW** | $\le 360$ Da | Monotonic decreasing: $1.0$ for $x \le 360$, drops to $0.0$ at $x = 500$ Da |
| **TPSA** | $40 - 90$ \AA$^2$ | Trapezoidal/Humped: $1.0$ for $40 \le x \le 90$; $0.0$ for $x < 20$ or $x > 120$ |
| **HBD** | $\le 0.5$ | Monotonic decreasing: $1.0$ for $x \le 0.5$, drops to $0.0$ at $x = 3.5$ |
| **pKa$_{\text{basic}}$** | $\le 8.0$ | Monotonic decreasing: $1.0$ for $x \le 8.0$, drops to $0.0$ at $x = 10.0$ |

Compounds achieving **$\text{CNS-MPO} \ge 4.0$** possess significantly elevated probability of central nervous system exposure and reduced P-glycoprotein (P-gp) efflux liability.

---

## 4. Multi-Parametric Consensus Scoring

To eliminate bias from any single computational scoring function, candidates are evaluated across four orthogonal dimensions:
1. Docking Energy ($E_{\text{dock}}$, kcal/mol; lower is better)
2. Pharmacophore Spatial Fitness ($S$, scale $0-1$; higher is better)
3. PLIF Tanimoto Similarity ($T_c$, scale $0-1$; higher is better)
4. CNS-MPO Score ($MPO$, scale $0-6$; higher is better)

### Standardized Z-Score Consensus
Each metric $k$ across the candidate population is normalized:
$$z_{i, k} = \frac{x_{i, k} - \mu_k}{\sigma_k}$$
For docking energy, the sign is inverted ($\tilde{z}_{i, \text{dock}} = -z_{i, \text{dock}}$). The composite Z-score is:
$$Z_i = w_{\text{dock}} \tilde{z}_{i, \text{dock}} + w_{\text{pharm}} z_{i, \text{pharm}} + w_{\text{plif}} z_{i, \text{plif}} + w_{\text{mpo}} z_{i, \text{mpo}}$$
The final consensus score is scaled to a standard $[0, 100]$ index:
$$\text{Score}_i = 50.0 + 12.5 \cdot Z_i$$

### Pareto Non-Dominated Selection
Candidate $A$ **dominates** candidate $B$ ($A \succ B$) if and only if:
$$\forall k \in \{ \text{dock}, \text{pharm}, \text{plif}, \text{mpo} \}, \quad x_{A, k} \text{ is at least as good as } x_{B, k}$$
$$\text{and } \exists k^*, \quad x_{A, k^*} \text{ is strictly better than } x_{B, k^*}$$

Candidates on the **Pareto frontier** represent optimal compromises that cannot be improved in any single property without degrading another.
