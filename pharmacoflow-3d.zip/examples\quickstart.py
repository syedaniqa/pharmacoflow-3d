"""
PharmacoFlow-3D Quickstart Benchmark Demonstration.

Demonstrates:
1. Loading the neurodegenerative ASAH1 target pocket and bioactive reference ligand
2. Generating 3D structure-guided pharmacophore features and PyMOL script
3. Screening the 6-compound benchmark library with PLIF and CNS-MPO profiling
4. Generating interactive 3D HTML visualization and results CSV
"""

import os
import sys

# Ensure local pharmacoflow package is on path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from pharmacoflow.core.structures import parse_pdb, parse_sdf
from pharmacoflow.screening.engine import VirtualScreeningPipeline
from pharmacoflow.visualizer.html_report import generate_3d_report


def run_demo():
    case_dir = os.path.join(current_dir, "neuro_case_study")
    rec_path = os.path.join(case_dir, "receptor.pdb")
    ref_path = os.path.join(case_dir, "reference_ligand.sdf")
    lib_path = os.path.join(case_dir, "screening_library.sdf")

    print("=" * 78)
    print(" PharmacoFlow-3D : Neurodegenerative Target Virtual Screening Benchmark")
    print("=" * 78)

    print(f"\n[1] Ingesting macromolecular receptor: {os.path.basename(rec_path)}")
    receptor = parse_pdb(rec_path)
    print(f"    Total Protein Residues: {len(receptor.residues)} | Pocket Heavy Atoms: {len(receptor.atoms)}")

    print(f"\n[2] Ingesting bioactive reference co-crystal ligand: {os.path.basename(ref_path)}")
    ref_ligands = parse_sdf(ref_path)
    ref_lig = ref_ligands[0]
    print(f"    Reference Ligand: {ref_lig.name} (MW: {ref_lig.molecular_weight()} Da)")

    print(f"\n[3] Ingesting candidate screening library: {os.path.basename(lib_path)}")
    library = parse_sdf(lib_path)
    print(f"    Loaded {len(library)} diverse candidates.")

    print("\n[4] Initializing Virtual Screening Pipeline...")
    pipeline = VirtualScreeningPipeline(
        pharmacophore_tolerance=1.3,
        partial_match_allowed=True,
        min_match_ratio=0.60,
        mpo_cutoff=4.0,
    )

    print("    Deriving 3D Structure-Guided Pharmacophore Hypothesis...")
    print("    Computing Protein-Ligand Interaction Fingerprints (PLIF)...")
    print("    Evaluating Pfizer CNS-MPO & Blood-Brain Barrier (BBB) Desirability...")
    print("    Running Multi-Parametric Consensus Ranking (Z-Score + Pareto Front)...")

    results = pipeline.run(receptor, ref_lig, library)

    print("\n" + "=" * 78)
    print(f"{'Rank':<5} {'Candidate Molecule':<20} {'Consensus':<11} {'Docking':<10} {'Pharm':<8} {'PLIF':<8} {'MPO':<6} {'Verdict'}")
    print("=" * 78)

    for item in results.ranked_candidates:
        mpo = results.mpo_profiles.get(item.name)
        m_res = results.match_results.get(item.name)
        cns_flag = "PASS [CNS]" if mpo and mpo.cns_favorable else "FAIL [Periphery]"
        pareto_mark = "*" if item.is_pareto_front else " "
        print(
            f"{item.rank:<2}{pareto_mark:<3} {item.name:<20} {item.consensus_score:<11.2f} "
            f"{item.docking_score:<10.2f} {item.pharmacophore_fitness:<8.3f} "
            f"{item.plif_similarity:<8.3f} {item.cns_mpo:<6.2f} {cns_flag}"
        )
    print("-" * 78)
    print("(*) Indicates Pareto-optimal non-dominated candidate")

    # Export artifacts
    csv_out = os.path.join(case_dir, "benchmark_results.csv")
    html_out = os.path.join(case_dir, "interactive_screening_report.html")
    pml_out = os.path.join(case_dir, "pharmacophore_features.pml")

    results.export_csv(csv_out)
    results.pharmacophore_model.export_pymol_script(pml_out)
    generate_3d_report(results, receptor, ref_lig, html_out)

    print(f"\n[+] Generated Interactive 3D WebGL Dashboard : {html_out}")
    print(f"[+] Exported Screening Results Table      : {csv_out}")
    print(f"[+] Exported PyMOL 3D Pharmacophore Script: {pml_out}")
    print("\nBenchmark completed successfully!\n")


if __name__ == "__main__":
    run_demo()
