"""
Core 3D Structural Chemistry and Coordinate Processing Module.

Provides pure-Python/NumPy-accelerated data structures for:
- 3D atomic coordinates and connectivity
- Macromolecular PDB and small-molecule SDF parsers
- Binding site pocket extraction by distance threshold
- Kabsch superposition and RMSD calculations
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Any


@dataclass
class Atom3D:
    """Represents a single 3D atom with coordinates, element, and topology metadata."""
    name: str
    element: str
    x: float
    y: float
    z: float
    charge: float = 0.0
    resname: str = "LIG"
    resnum: int = 1
    chain: str = "A"
    is_hetero: bool = False
    bfactor: float = 0.0
    index: int = 0

    @property
    def coords(self) -> Tuple[float, float, float]:
        return (self.x, self.y, self.z)

    def distance_to(self, other: Atom3D) -> float:
        """Euclidean distance to another atom in Angstroms."""
        dx = self.x - other.x
        dy = self.y - other.y
        dz = self.z - other.z
        return math.sqrt(dx * dx + dy * dy + dz * dz)


@dataclass
class Bond:
    """Covalent bond representation between two atom indices."""
    atom1_idx: int
    atom2_idx: int
    order: int = 1  # 1=single, 2=double, 3=triple, 4=aromatic


@dataclass
class Residue3D:
    """A biological residue containing grouped atoms."""
    name: str
    resnum: int
    chain: str
    atoms: List[Atom3D] = field(default_factory=list)

    @property
    def centroid(self) -> Tuple[float, float, float]:
        if not self.atoms:
            return (0.0, 0.0, 0.0)
        sx = sum(a.x for a in self.atoms)
        sy = sum(a.y for a in self.atoms)
        sz = sum(a.z for a in self.atoms)
        n = len(self.atoms)
        return (sx / n, sy / n, sz / n)


@dataclass
class Molecule3D:
    """A small molecule or ligand with 3D coordinates, bonds, and properties."""
    name: str
    atoms: List[Atom3D] = field(default_factory=list)
    bonds: List[Bond] = field(default_factory=list)
    properties: Dict[str, Any] = field(default_factory=dict)

    @property
    def num_atoms(self) -> int:
        return len(self.atoms)

    @property
    def num_heavy_atoms(self) -> int:
        return sum(1 for a in self.atoms if a.element.upper() != "H")

    @property
    def centroid(self) -> Tuple[float, float, float]:
        if not self.atoms:
            return (0.0, 0.0, 0.0)
        sx = sum(a.x for a in self.atoms)
        sy = sum(a.y for a in self.atoms)
        sz = sum(a.z for a in self.atoms)
        n = len(self.atoms)
        return (sx / n, sy / n, sz / n)

    def get_coordinates(self) -> List[Tuple[float, float, float]]:
        return [(a.x, a.y, a.z) for a in self.atoms]

    def translate(self, dx: float, dy: float, dz: float) -> Molecule3D:
        """Return translated copy of the molecule."""
        new_atoms = [
            Atom3D(
                name=a.name,
                element=a.element,
                x=a.x + dx,
                y=a.y + dy,
                z=a.z + dz,
                charge=a.charge,
                resname=a.resname,
                resnum=a.resnum,
                chain=a.chain,
                is_hetero=a.is_hetero,
                bfactor=a.bfactor,
                index=a.index,
            )
            for a in self.atoms
        ]
        return Molecule3D(name=self.name, atoms=new_atoms, bonds=list(self.bonds), properties=dict(self.properties))

    def molecular_weight(self) -> float:
        """Calculate approximate molecular weight based on standard atomic weights."""
        weights = {
            "H": 1.008, "C": 12.011, "N": 14.007, "O": 15.999, "F": 18.998,
            "P": 30.974, "S": 32.06, "CL": 35.45, "BR": 79.904, "I": 126.90
        }
        mw = 0.0
        for a in self.atoms:
            elem = a.element.strip().upper()
            mw += weights.get(elem, 12.0)
        return round(mw, 3)

    def rotatable_bonds_count(self) -> int:
        """Estimate rotatable single bonds (non-terminal, non-ring approximate)."""
        # Count single bonds not involving terminal atoms (atoms with degree 1)
        degrees = [0] * len(self.atoms)
        for b in self.bonds:
            if 0 <= b.atom1_idx < len(degrees) and 0 <= b.atom2_idx < len(degrees):
                degrees[b.atom1_idx] += 1
                degrees[b.atom2_idx] += 1
        
        rotatable = 0
        for b in self.bonds:
            if b.order == 1:
                elem1 = self.atoms[b.atom1_idx].element.upper()
                elem2 = self.atoms[b.atom2_idx].element.upper()
                if elem1 != "H" and elem2 != "H":
                    if degrees[b.atom1_idx] > 1 and degrees[b.atom2_idx] > 1:
                        rotatable += 1
        return rotatable


@dataclass
class ProteinComplex:
    """A macromolecular receptor structure containing protein residues and optional ligands."""
    name: str
    atoms: List[Atom3D] = field(default_factory=list)
    residues: List[Residue3D] = field(default_factory=list)

    def get_binding_pocket(self, ligand: Molecule3D, cutoff_radius: float = 6.0) -> List[Residue3D]:
        """
        Extract all protein residues having at least one heavy atom within
        the specified cutoff radius (Angstroms) of any ligand atom.
        """
        ligand_coords = [a.coords for a in ligand.atoms if a.element.upper() != "H"]
        if not ligand_coords:
            return []

        pocket_residues = []
        for res in self.residues:
            is_in_pocket = False
            for p_atom in res.atoms:
                if p_atom.element.upper() == "H":
                    continue
                for lx, ly, lz in ligand_coords:
                    dx = p_atom.x - lx
                    dy = p_atom.y - ly
                    dz = p_atom.z - lz
                    dist_sq = dx * dx + dy * dy + dz * dz
                    if dist_sq <= cutoff_radius * cutoff_radius:
                        is_in_pocket = True
                        break
                if is_in_pocket:
                    break
            if is_in_pocket:
                pocket_residues.append(res)
        return pocket_residues


# ============================================================================
# File Parsers & Writers (PDB & SDF)
# ============================================================================

def parse_pdb(filepath_or_content: str, is_content: bool = False) -> ProteinComplex:
    """Parse standard PDB format into ProteinComplex with hierarchical Residue3D objects."""
    if is_content:
        lines = filepath_or_content.splitlines()
    else:
        with open(filepath_or_content, "r", encoding="utf-8") as f:
            lines = f.readlines()
    
    atoms: List[Atom3D] = []
    residue_map: Dict[Tuple[str, int, str], Residue3D] = {}

    for idx, line in enumerate(lines):
        record_type = line[:6].strip()
        if record_type in ("ATOM", "HETATM"):
            try:
                atom_name = line[12:16].strip()
                res_name = line[17:20].strip()
                chain_id = line[21:22].strip() or "A"
                res_seq = int(line[22:26].strip())
                x = float(line[30:38].strip())
                y = float(line[38:46].strip())
                z = float(line[46:54].strip())
                occupancy = float(line[54:60].strip()) if len(line) >= 60 and line[54:60].strip() else 1.0
                bfactor = float(line[60:66].strip()) if len(line) >= 66 and line[60:66].strip() else 0.0
                element = line[76:78].strip() if len(line) >= 78 else atom_name[:1]
                if not element:
                    element = atom_name[:1]

                atom = Atom3D(
                    name=atom_name,
                    element=element,
                    x=x,
                    y=y,
                    z=z,
                    resname=res_name,
                    resnum=res_seq,
                    chain=chain_id,
                    is_hetero=(record_type == "HETATM"),
                    bfactor=bfactor,
                    index=len(atoms)
                )
                atoms.append(atom)

                key = (chain_id, res_seq, res_name)
                if key not in residue_map:
                    residue_map[key] = Residue3D(name=res_name, resnum=res_seq, chain=chain_id, atoms=[])
                residue_map[key].atoms.append(atom)
            except Exception:
                continue

    return ProteinComplex(
        name="ParsedProtein",
        atoms=atoms,
        residues=list(residue_map.values())
    )


def parse_sdf(filepath_or_content: str, is_content: bool = False) -> List[Molecule3D]:
    """Parse V2000/V3000 MDL SD file format into a list of Molecule3D objects."""
    if is_content:
        text = filepath_or_content
    else:
        with open(filepath_or_content, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    records = text.split("$$$$\n")
    if len(records) == 1 and "$$$$" in text:
        records = text.split("$$$$")

    molecules: List[Molecule3D] = []

    for block in records:
        block = block.strip()
        if not block:
            continue
        lines = block.splitlines()
        if len(lines) < 4:
            continue

        mol_name = lines[0].strip() or f"Mol_{len(molecules)+1}"
        counts_line = lines[3]
        try:
            num_atoms = int(counts_line[0:3].strip())
            num_bonds = int(counts_line[3:6].strip())
        except ValueError:
            tokens = counts_line.split()
            if len(tokens) >= 2:
                num_atoms = int(tokens[0])
                num_bonds = int(tokens[1])
            else:
                continue

        mol_atoms: List[Atom3D] = []
        atom_start = 4
        for i in range(num_atoms):
            line_idx = atom_start + i
            if line_idx >= len(lines):
                break
            aline = lines[line_idx]
            parts = aline.split()
            if len(parts) >= 4:
                x = float(parts[0])
                y = float(parts[1])
                z = float(parts[2])
                elem = parts[3]
                atom = Atom3D(
                    name=f"{elem}{i+1}",
                    element=elem,
                    x=x,
                    y=y,
                    z=z,
                    resname="LIG",
                    resnum=1,
                    chain="L",
                    index=i
                )
                mol_atoms.append(atom)

        mol_bonds: List[Bond] = []
        bond_start = atom_start + num_atoms
        for i in range(num_bonds):
            line_idx = bond_start + i
            if line_idx >= len(lines):
                break
            bline = lines[line_idx]
            parts = bline.split()
            if len(parts) >= 3:
                a1 = int(parts[0]) - 1
                a2 = int(parts[1]) - 1
                order = int(parts[2])
                mol_bonds.append(Bond(atom1_idx=a1, atom2_idx=a2, order=order))

        # Parse SDF properties (> <PROP_NAME>)
        properties: Dict[str, Any] = {}
        curr_prop_name = None
        for i in range(bond_start + num_bonds, len(lines)):
            line = lines[i].strip()
            if line.startswith("> <") and line.endswith(">"):
                curr_prop_name = line[3:-1].strip()
            elif line.startswith(">") and "<" in line and ">" in line:
                start = line.find("<") + 1
                end = line.find(">", start)
                curr_prop_name = line[start:end].strip()
            elif curr_prop_name:
                if line:
                    properties[curr_prop_name] = line
                    curr_prop_name = None

        mol = Molecule3D(name=mol_name, atoms=mol_atoms, bonds=mol_bonds, properties=properties)
        molecules.append(mol)

    return molecules


def write_sdf(molecules: List[Molecule3D], filepath: str) -> None:
    """Export molecules into MDL SD file format."""
    with open(filepath, "w", encoding="utf-8") as f:
        for mol in molecules:
            f.write(f"{mol.name}\n")
            f.write("  PharmacoFlow-3D\n\n")
            f.write(f"{len(mol.atoms):3d}{len(mol.bonds):3d}  0  0  0  0  0  0  0  0999 V2000\n")
            for atom in mol.atoms:
                f.write(f"{atom.x:10.4f}{atom.y:10.4f}{atom.z:10.4f} {atom.element:<3s} 0  0  0  0  0  0  0  0  0  0  0  0\n")
            for bond in mol.bonds:
                f.write(f"{bond.atom1_idx+1:3d}{bond.atom2_idx+1:3d}{bond.order:3d}  0  0  0  0\n")
            for k, v in mol.properties.items():
                f.write(f"> <{k}>\n{v}\n\n")
            f.write("$$$$\n")


# ============================================================================
# Vector Math, RMSD, and Kabsch Structural Superposition
# ============================================================================

def calculate_rmsd(coords_a: List[Tuple[float, float, float]], coords_b: List[Tuple[float, float, float]]) -> float:
    """Calculate Root Mean Square Deviation (RMSD) between two sets of 3D coordinates."""
    if len(coords_a) != len(coords_b) or len(coords_a) == 0:
        raise ValueError("Coordinate sets must be non-empty and of identical length.")
    sq_sum = 0.0
    for (x1, y1, z1), (x2, y2, z2) in zip(coords_a, coords_b):
        dx = x1 - x2
        dy = y1 - y2
        dz = z1 - z2
        sq_sum += dx * dx + dy * dy + dz * dz
    return math.sqrt(sq_sum / len(coords_a))


def kabsch_align(
    coords_mobile: List[Tuple[float, float, float]],
    coords_target: List[Tuple[float, float, float]]
) -> Tuple[List[Tuple[float, float, float]], float]:
    """
    Superpose mobile coordinates onto target coordinates using the Kabsch algorithm.
    Returns (aligned_coordinates, final_rmsd).
    """
    n = len(coords_mobile)
    if n != len(coords_target) or n < 3:
        return list(coords_mobile), calculate_rmsd(coords_mobile, coords_target) if n > 0 else 0.0

    # Compute centroids
    cx_m = sum(c[0] for c in coords_mobile) / n
    cy_m = sum(c[1] for c in coords_mobile) / n
    cz_m = sum(c[2] for c in coords_mobile) / n

    cx_t = sum(c[0] for c in coords_target) / n
    cy_t = sum(c[1] for c in coords_target) / n
    cz_t = sum(c[2] for c in coords_target) / n

    # Center coordinates
    p = [(c[0] - cx_m, c[1] - cy_m, c[2] - cz_m) for c in coords_mobile]
    q = [(c[0] - cx_t, c[1] - cy_t, c[2] - cz_t) for c in coords_target]

    try:
        import numpy as np  # type: ignore
        P = np.array(p)
        Q = np.array(q)
        # Covariance matrix H = P^T * Q
        H = np.dot(P.T, Q)
        U, S, Vt = np.linalg.svd(H)
        R = np.dot(Vt.T, U.T)
        # Reflection correction
        if np.linalg.det(R) < 0:
            Vt[-1, :] *= -1
            R = np.dot(Vt.T, U.T)
        P_rot = np.dot(P, R.T)
        aligned = [(float(pt[0] + cx_t), float(pt[1] + cy_t), float(pt[2] + cz_t)) for pt in P_rot]
        return aligned, calculate_rmsd(aligned, coords_target)
    except Exception:
        # Fallback translation alignment
        aligned = [(c[0] - cx_m + cx_t, c[1] - cy_m + cy_t, c[2] - cz_m + cz_t) for c in coords_mobile]
        return aligned, calculate_rmsd(aligned, coords_target)
