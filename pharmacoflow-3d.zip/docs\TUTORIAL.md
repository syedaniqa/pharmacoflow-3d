# PharmacoFlow-3D User Guide & Tutorial

Welcome to `PharmacoFlow-3D`. This tutorial walks you through running virtual screening campaigns, generating 3D pharmacophore hypotheses, evaluating CNS drug-likeness, and exploring interactive 3D reports.

---

## 1. Installation

### Standalone Installation
`PharmacoFlow-3D` is engineered to have zero mandatory external binary dependencies for standard workflows. Clone and install locally:

```bash
git clone https://github.com/syedaniqa/pharmacoflow-3d.git
cd pharmacoflow-3d
pip install -e .
```

### Optional Accelerated Scientific Stack
For large multi-million conformer libraries, install NumPy and SciPy:
```bash
pip install -r requirements.txt
```

---

## 2. Fast 1-Minute Demonstration

Run the built-in neurodegeneration virtual screening benchmark:
```bash
python examples/quickstart.py
```
Or via the command-line interface:
```bash
pharmacoflow quickstart
```

This will:
1. Ingest the catalytic pocket coordinates of human acid ceramidase (*ASAH1*, linked to SMA-PME and Farber disease).
2. Extract the co-crystallized bioactive reference inhibitor.
3. Automatically derive 3D structure-guided pharmacophoric feature spheres.
4. Screen a diverse candidate library.
5. Generate `interactive_screening_report.html`, `benchmark_results.csv`, and `pharmacophore_features.pml`.

---

## 3. Command-Line Interface (CLI) Workflows

### Run Virtual Screening Campaign
```bash
pharmacoflow screen \
    --receptor my_target.pdb \
    --reference bioactive_ligand.sdf \
    --library candidate_library.sdf \
    --output-dir ./screening_output \
    --tolerance 1.3 \
    --mpo-cutoff 4.0
```

### Generate 3D Pharmacophore & PyMOL Script
```bash
pharmacoflow generate \
    --ligand lead_molecule.sdf \
    --receptor my_target.pdb \
    --output model_hypo.json \
    --pymol pharmacophore_spheres.pml
```

Open the generated `.pml` directly inside PyMOL:
```bash
pymol my_target.pdb lead_molecule.sdf pharmacophore_spheres.pml
```

### Compute Interaction Fingerprints (PLIF)
```bash
pharmacoflow plif \
    --receptor my_target.pdb \
    --ligand docked_pose.sdf
```

### Profile CNS-MPO & Druggability
```bash
pharmacoflow cns-mpo --library candidate_library.sdf
```

---

## 4. Python API Reference

You can also integrate `PharmacoFlow-3D` into your own automated Jupyter notebooks or Python workflows:

```python
from pharmacoflow.core.structures import parse_pdb, parse_sdf
from pharmacoflow.screening.engine import VirtualScreeningPipeline
from pharmacoflow.visualizer.html_report import generate_3d_report

# 1. Load 3D coordinates
receptor = parse_pdb("receptor.pdb")
reference_ligand = parse_sdf("reference.sdf")[0]
screening_library = parse_sdf("library.sdf")

# 2. Run Virtual Screening
pipeline = VirtualScreeningPipeline(
    pharmacophore_tolerance=1.3,
    partial_match_allowed=True,
    min_match_ratio=0.60,
    mpo_cutoff=4.0
)
results = pipeline.run(receptor, reference_ligand, screening_library)

# 3. Export ranked results and interactive 3D WebGL dashboard
results.export_csv("results.csv")
generate_3d_report(results, receptor, reference_ligand, "report.html")

print("Virtual screening campaign successfully executed!")
```
