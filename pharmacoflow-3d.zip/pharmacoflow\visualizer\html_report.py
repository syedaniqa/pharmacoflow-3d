"""
Interactive 3D WebGL HTML Report Generator.

Embeds:
- 3Dmol.js WebGL canvas visualizing receptor-ligand complex
- Dynamic 3D pharmacophore tolerance spheres with canonical CADD color schemes
- Interactive hit table with multi-parameter filtering (CNS-MPO, Docking, PLIF)
- SVG radar chart for top lead multiparameter CNS profile
"""

from __future__ import annotations
import math
import json
from typing import Optional, List, Dict
from pharmacoflow.core.structures import ProteinComplex, Molecule3D
from pharmacoflow.pharmacophore.features import FEATURE_COLORS, FeatureType
from pharmacoflow.screening.engine import ScreeningResult


def generate_3d_report(
    screening_result: ScreeningResult,
    receptor: ProteinComplex,
    reference_ligand: Molecule3D,
    output_html_path: str,
    title: str = "PharmacoFlow-3D Virtual Screening Report",
) -> None:
    """Generate self-contained interactive 3D HTML report."""
    top_candidates = screening_result.ranked_candidates[:15]
    top_hit = top_candidates[0] if top_candidates else None
    top_mpo = screening_result.mpo_profiles.get(top_hit.name) if top_hit else None

    # Prepare features for 3Dmol.js rendering
    model = screening_result.pharmacophore_model
    features_json = []
    for f in model.features:
        rgb = FEATURE_COLORS.get(f.feature_type, (0.5, 0.5, 0.5))
        features_json.append({
            "type": f.feature_type.value,
            "x": f.x,
            "y": f.y,
            "z": f.z,
            "radius": f.tolerance,
            "color": f"rgb({int(rgb[0]*255)}, {int(rgb[1]*255)}, {int(rgb[2]*255)})",
            "label": f.label or f.feature_type.value,
            "residue": f.residue_partner,
        })

    # Prepare pocket PDB data string (binding residues only for light payload)
    pocket_res = receptor.get_binding_pocket(reference_ligand, cutoff_radius=5.5)
    pdb_lines = []
    atom_idx = 1
    for res in pocket_res:
        for a in res.atoms:
            pdb_lines.append(
                f"ATOM  {atom_idx:5d} {a.name:<4s} {res.name:3s} {res.chain:1s}{res.resnum:4d}    "
                f"{a.x:8.3f}{a.y:8.3f}{a.z:8.3f}{1.0:6.2f}{a.bfactor:6.2f}          {a.element:>2s}"
            )
            atom_idx += 1
    pocket_pdb_str = "\n".join(pdb_lines)

    # Reference ligand SDF string
    lig_lines = [
        f"{reference_ligand.name}",
        "  PharmacoFlow-3D",
        "",
        f"{len(reference_ligand.atoms):3d}{len(reference_ligand.bonds):3d}  0  0  0  0  0  0  0  0999 V2000",
    ]
    for a in reference_ligand.atoms:
        lig_lines.append(f"{a.x:10.4f}{a.y:10.4f}{a.z:10.4f} {a.element:<3s} 0  0  0  0  0  0  0  0  0  0  0  0")
    for b in reference_ligand.bonds:
        lig_lines.append(f"{b.atom1_idx+1:3d}{b.atom2_idx+1:3d}{b.order:3d}  0  0  0  0")
    lig_lines.append("$$$$\n")
    ref_lig_sdf = "\n".join(lig_lines)

    # Prepare Candidate rows HTML
    rows_html = []
    for item in top_candidates:
        mpo = screening_result.mpo_profiles.get(item.name)
        m_res = screening_result.match_results.get(item.name)
        cns_badge = '<span class="badge badge-success">CNS Pass</span>' if (mpo and mpo.cns_favorable) else '<span class="badge badge-warning">Low CNS</span>'
        pareto_badge = '<span class="badge badge-primary">Pareto</span>' if item.is_pareto_front else ''

        rows_html.append(f"""
        <tr>
            <td><strong>#{item.rank}</strong></td>
            <td><strong>{item.name}</strong> {pareto_badge}</td>
            <td><div class="score-pill">{item.consensus_score}</div></td>
            <td>{item.docking_score:.2f}</td>
            <td>{item.pharmacophore_fitness:.3f}</td>
            <td>{item.plif_similarity:.3f}</td>
            <td><strong>{item.cns_mpo:.2f}</strong> / 6.0 {cns_badge}</td>
            <td>{mpo.mw if mpo else 'N/A'}</td>
            <td>{mpo.clogp if mpo else 'N/A'}</td>
            <td>{mpo.tpsa if mpo else 'N/A'}</td>
        </tr>
        """)

    # Radar chart points for top MPO
    radar_svg = ""
    if top_mpo:
        comp = top_mpo.component_scores
        labels = ["ClogP", "ClogD", "MW", "TPSA", "HBD", "pKa"]
        values = [comp.get(k, 0.5) for k in labels]
        
        # 6-axis polygon coords (center 120, 120, radius 80)
        cx, cy, r = 120, 120, 80
        pts = []
        axes_svg = []
        for i, val in enumerate(values):
            angle = (i * 60 - 90) * (3.14159 / 180)
            x_edge = cx + r * math.cos(angle)
            y_edge = cy + r * math.sin(angle)
            axes_svg.append(f'<line x1="{cx}" y1="{cy}" x2="{x_edge:.1f}" y2="{y_edge:.1f}" stroke="#cbd5e1" stroke-dasharray="2,2"/>')
            
            # Label
            lx = cx + (r + 18) * math.cos(angle)
            ly = cy + (r + 18) * math.sin(angle)
            axes_svg.append(f'<text x="{lx:.1f}" y="{ly:.1f}" font-size="10" text-anchor="middle" fill="#475569">{labels[i]}</text>')

            # Value point
            pv = val * r
            px = cx + pv * math.cos(angle)
            py = cy + pv * math.sin(angle)
            pts.append(f"{px:.1f},{py:.1f}")

        radar_svg = f"""
        <svg viewBox="0 0 240 240" class="radar-chart">
            <circle cx="120" cy="120" r="80" fill="none" stroke="#e2e8f0" stroke-width="1"/>
            <circle cx="120" cy="120" r="53" fill="none" stroke="#e2e8f0" stroke-width="1"/>
            <circle cx="120" cy="120" r="26" fill="none" stroke="#e2e8f0" stroke-width="1"/>
            {''.join(axes_svg)}
            <polygon points="{' '.join(pts)}" fill="rgba(37, 99, 235, 0.35)" stroke="#2563eb" stroke-width="2"/>
        </svg>
        """

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <!-- 3Dmol.js WebGL Molecular Visualizer -->
    <script src="https://3Dmol.org/build/3Dmol-min.js"></script>
    <style>
        :root {{
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --bg-main: #f8fafc;
            --card-bg: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --success: #10b981;
            --warning: #f59e0b;
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--bg-main);
            color: var(--text-main);
            padding: 24px;
            line-height: 1.5;
        }}
        .header {{
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 24px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }}
        .header h1 {{ font-size: 28px; font-weight: 700; margin-bottom: 8px; }}
        .header p {{ color: #94a3b8; font-size: 14px; max-width: 800px; }}
        .meta-badges {{ margin-top: 16px; display: flex; gap: 12px; flex-wrap: wrap; }}
        .meta-badge {{
            background: rgba(255, 255, 255, 0.12);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            color: #e2e8f0;
        }}
        .grid {{
            display: grid;
            grid-template-columns: 1.3fr 0.7fr;
            gap: 24px;
            margin-bottom: 24px;
        }}
        @media (max-width: 1024px) {{ .grid {{ grid-template-columns: 1fr; }} }}
        .card {{
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }}
        .card h2 {{
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 16px;
            color: #1e293b;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        #viewer_container {{
            width: 100%;
            height: 480px;
            position: relative;
            background: #090d16;
            border-radius: 8px;
            overflow: hidden;
        }}
        .legend {{
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 12px;
            font-size: 12px;
        }}
        .legend-item {{ display: flex; align-items: center; gap: 6px; }}
        .legend-dot {{ width: 12px; height: 12px; border-radius: 50%; display: inline-block; }}
        .table-container {{ overflow-x: auto; }}
        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            text-align: left;
        }}
        th {{
            background: #f1f5f9;
            color: #475569;
            padding: 10px 12px;
            font-weight: 600;
            border-bottom: 2px solid var(--border);
        }}
        td {{
            padding: 10px 12px;
            border-bottom: 1px solid var(--border);
        }}
        tr:hover {{ background-color: #f8fafc; }}
        .score-pill {{
            background: #dbeafe;
            color: #1e40af;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 600;
            display: inline-block;
        }}
        .badge {{
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 600;
        }}
        .badge-success {{ background: #dcfce7; color: #166534; }}
        .badge-warning {{ background: #fef3c7; color: #92400e; }}
        .badge-primary {{ background: #ede9fe; color: #5b21b6; }}
        .kpi-row {{
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-bottom: 16px;
        }}
        .kpi-card {{
            background: #f8fafc;
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 12px;
            text-align: center;
        }}
        .kpi-num {{ font-size: 22px; font-weight: 700; color: var(--primary); }}
        .kpi-label {{ font-size: 11px; color: var(--text-muted); text-transform: uppercase; }}
        .radar-chart {{ max-width: 220px; margin: 0 auto; display: block; }}
        .footer {{
            margin-top: 32px;
            text-align: center;
            font-size: 12px;
            color: var(--text-muted);
        }}
    </style>
</head>
<body>

    <div class="header">
        <h1>PharmacoFlow-3D &mdash; Virtual Screening Dashboard</h1>
        <p>Dynamic Ensemble Pharmacophore Modeling, Protein-Ligand Interaction Fingerprints (PLIF), and CNS-MPO Consensus Scoring</p>
        <div class="meta-badges">
            <span class="meta-badge">Target: {screening_result.receptor_name}</span>
            <span class="meta-badge">Bioactive Reference: {screening_result.reference_ligand_name}</span>
            <span class="meta-badge">Screened Library: {screening_result.num_screened} conformers</span>
            <span class="meta-badge">Pharmacophore Spheres: {model.num_features}</span>
            <span class="meta-badge">Lead Candidate: {top_hit.name if top_hit else 'None'}</span>
        </div>
    </div>

    <div class="grid">
        <!-- 3D Visualization Card -->
        <div class="card">
            <h2>
                Interactive 3D Active Site &amp; Pharmacophore Spheres
                <span style="font-size: 12px; font-weight: normal; color: var(--text-muted);">Rotate: Left Click | Zoom: Scroll | Pan: Right Click</span>
            </h2>
            <div id="viewer_container"></div>
            <div class="legend">
                <div class="legend-item"><span class="legend-dot" style="background: rgb(51, 102, 230);"></span> H-Bond Donor (HBD)</div>
                <div class="legend-item"><span class="legend-dot" style="background: rgb(230, 51, 51);"></span> H-Bond Acceptor (HBA)</div>
                <div class="legend-item"><span class="legend-dot" style="background: rgb(230, 128, 25);"></span> Aromatic Centroid</div>
                <div class="legend-item"><span class="legend-dot" style="background: rgb(51, 204, 51);"></span> Hydrophobic</div>
                <div class="legend-item"><span class="legend-dot" style="background: rgb(76, 204, 230);"></span> Basic / Cation</div>
                <div class="legend-item"><span class="legend-dot" style="background: #ffffff; border: 1px solid #999;"></span> Docked Ligand</div>
            </div>
        </div>

        <!-- Lead Profiler Card -->
        <div class="card">
            <h2>Lead CNS-MPO &amp; Druggability Profile</h2>
            <div class="kpi-row">
                <div class="kpi-card">
                    <div class="kpi-num">{top_hit.consensus_score if top_hit else '0'}</div>
                    <div class="kpi-label">Consensus Score</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-num">{top_hit.docking_score if top_hit else '0'} <span style="font-size:12px;">kcal/mol</span></div>
                    <div class="kpi-label">Docking Affinity</div>
                </div>
                <div class="kpi-card">
                    <div class="kpi-num">{top_mpo.total_mpo_score if top_mpo else '0'} <span style="font-size:12px;">/ 6</span></div>
                    <div class="kpi-label">CNS-MPO Score</div>
                </div>
            </div>
            
            <h3 style="font-size: 13px; color: var(--text-muted); margin-bottom: 8px; text-align: center;">
                Pfizer CNS-MPO Desirability Radar ({top_hit.name if top_hit else ''})
            </h3>
            {radar_svg}
            
            <div style="font-size: 12px; color: #475569; margin-top: 14px; background: #f8fafc; padding: 10px; border-radius: 6px;">
                <strong>CNS Penetration Assessment:</strong> {top_mpo.summary_verdict if top_mpo else 'N/A'}<br>
                <strong>Ro5 Violations:</strong> {top_mpo.ro5_violations if top_mpo else 0} &bull; 
                <strong>Veber Violations:</strong> {top_mpo.veber_violations if top_mpo else 0} &bull;
                <strong>PAINS Alert:</strong> {'Yes' if top_mpo and top_mpo.pains_alert else 'Clean (None)'}
            </div>
        </div>
    </div>

    <!-- Ranked Hits Table -->
    <div class="card">
        <h2>Ranked Virtual Screening Candidate Hits</h2>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Candidate Molecule</th>
                        <th>Consensus (0-100)</th>
                        <th>Docking &Delta;G (kcal/mol)</th>
                        <th>Pharm Fitness</th>
                        <th>PLIF Similarity</th>
                        <th>CNS-MPO Score</th>
                        <th>MW (Da)</th>
                        <th>ClogP</th>
                        <th>TPSA (&Aring;&sup2;)</th>
                    </tr>
                </thead>
                <tbody>
                    {''.join(rows_html)}
                </tbody>
            </table>
        </div>
    </div>

    <div class="footer">
        Generated with <strong>PharmacoFlow-3D</strong> &bull; Developed by Syeda Aniqa Bukhari &bull; Open-Source Computational Drug Design Pipeline
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {{
            const element = document.getElementById('viewer_container');
            const config = {{ backgroundColor: '#0b1120' }};
            const viewer = $3Dmol.createViewer(element, config);

            // 1. Load Pocket PDB
            const pocketPdb = `{pocket_pdb_str}`;
            viewer.addModel(pocketPdb, "pdb");
            viewer.setStyle({{resn: 'LIG'}}, {{stick: {{colorscheme: 'cyanCarbon'}}}});
            viewer.setStyle({{hetflag: false}}, {{stick: {{colorscheme: 'lightgrey', radius: 0.12}}}});

            // 2. Load Reference Ligand SDF
            const refSdf = `{ref_lig_sdf}`;
            viewer.addModel(refSdf, "sdf");
            viewer.setStyle({{model: 1}}, {{stick: {{colorscheme: 'whiteCarbon', radius: 0.28}}}});

            // 3. Render Pharmacophore Tolerance Spheres
            const features = {json.dumps(features_json)};
            features.forEach(f => {{
                viewer.addSphere({{
                    center: {{x: f.x, y: f.y, z: f.z}},
                    radius: f.radius,
                    color: f.color,
                    alpha: 0.45,
                    wireframe: false
                }});
            }});

            viewer.zoomTo();
            viewer.render();
        }});
    </script>
</body>
</html>
"""
    with open(output_html_path, "w", encoding="utf-8") as f:
        f.write(html_content)
