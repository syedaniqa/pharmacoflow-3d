# LinkedIn Announcement & Showcase Post

*Copy and paste the text below directly onto LinkedIn when you publish your repository!*

---

🚀 **Excited to open-source PharmacoFlow-3D: Bridging the Gap Between Molecular Docking and Real-World Neurotherapeutics!**

In Computer-Aided Drug Design (CADD), high-throughput virtual screening (HTVS) has long faced a persistent bottleneck: **rigid receptor docking yields an estimated 80–90% false-positive rate.** Scoring functions often reward non-specific binding while overlooking crucial directional pharmacophoric vectors, solvent networks, and induced-fit plasticity. 

Even worse, in neurodegenerative drug discovery (such as SMA-PME, ALS, and Parkinson's), potent *in vitro* binders routinely fail *in vivo* because they fail to cross the Blood-Brain Barrier (BBB).

To address these challenges directly, I built and open-sourced **PharmacoFlow-3D** — an automated, end-to-end virtual screening and ensemble pharmacophore modeling pipeline.

🔬 **Key Technical Innovations:**
1. **Dynamic Structure-Guided 3D Pharmacophore Engine:** Automatically extracts spatial tolerance spheres and directional orientation vectors (HBD, HBA, Aromatic $\pi$-systems, Lipophilic centers, Ionizable groups) anchored to key catalytic residues.
2. **Protein-Ligand Interaction Fingerprints (PLIF):** Encodes non-covalent contacts (H-bonds, salt bridges, $\pi$-$\pi$ stacking, cation-$\pi$, halogen bonds, hydrophobic contacts) into a 7-bit per-residue fingerprint, computing Tanimoto similarity against bioactive co-crystal reference complexes.
3. **Pfizer CNS-MPO Druggability Profiler:** Implements 6 continuous sigmoidal desirability functions (MW, ClogP, ClogD7.4, TPSA, HBD, basic pKa) alongside Lipinski Rule of 5, Veber, and PAINS filter alerts to prioritize blood-brain barrier penetrant leads.
4. **Multi-Parametric Consensus & Pareto Frontier Selection:** Unifies docking binding free energy, pharmacophore spatial fitness, PLIF similarity, and CNS-MPO scores using standardized Z-scores, Borda rank aggregation, and non-dominated sorting.
5. **Interactive 3D WebGL Dashboards:** Automatically generates standalone, zero-dependency HTML reports powered by 3Dmol.js to interactively inspect active site meshes, docked poses, and pharmacophore tolerance spheres right in the browser.

💡 **Case Study Highlight:**
Benchmarked against the human Acid Ceramidase (*ASAH1*) catalytic pocket—a central target in Spinal Muscular Atrophy with Progressive Myoclonic Epilepsy (SMA-PME)—the pipeline successfully filtered out high-affinity but non-permeant polar decoys, surfacing drug-like brain-penetrant leads on the Pareto-optimal frontier.

🔗 **Explore the GitHub Repository & Documentation:**
👉 [https://github.com/syedaniqa/pharmacoflow-3d](https://github.com/syedaniqa/pharmacoflow-3d)

The pipeline is completely modular, open-source under the MIT license, and comes with full test coverage (100% passing tests) and a 1-minute quickstart benchmark.

I would love feedback and collaboration from fellow bioinformaticians, computational chemists, and medicinal chemists! What strategies do you rely on most to reduce false positives in your virtual screening workflows?

---

#Bioinformatics #CADD #ComputationalChemistry #DrugDiscovery #Cheminformatics #MolecularDocking #Pharmacophore #Python #OpenSource #StructuralBiology #Neurodegeneration #Biostatistics
