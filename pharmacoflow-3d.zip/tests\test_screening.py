"""
Unit tests for End-to-End Virtual Screening Pipeline and Consensus Scoring.
"""

import unittest
import tempfile
import os
from pharmacoflow.core.structures import parse_pdb, parse_sdf
from pharmacoflow.screening.engine import VirtualScreeningPipeline
from pharmacoflow.screening.consensus import ConsensusScorer, CandidateScoreRow


class TestScreening(unittest.TestCase):

    def test_consensus_scorer_ranking(self):
        scorer = ConsensusScorer()
        cands = [
            CandidateScoreRow(
                name="Mol_Best",
                docking_score=-10.5,
                pharmacophore_fitness=0.95,
                plif_similarity=0.90,
                cns_mpo=5.5,
                extra_props={},
            ),
            CandidateScoreRow(
                name="Mol_Worst",
                docking_score=-4.0,
                pharmacophore_fitness=0.10,
                plif_similarity=0.10,
                cns_mpo=2.0,
                extra_props={},
            ),
        ]
        ranked = scorer.rank(cands)
        self.assertEqual(len(ranked), 2)
        self.assertEqual(ranked[0].name, "Mol_Best")
        self.assertEqual(ranked[0].rank, 1)
        self.assertTrue(ranked[0].is_pareto_front)
        self.assertGreater(ranked[0].consensus_score, ranked[1].consensus_score)

    def test_pipeline_execution_with_benchmark_data(self):
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        rec_path = os.path.join(root, "examples", "neuro_case_study", "receptor.pdb")
        ref_path = os.path.join(root, "examples", "neuro_case_study", "reference_ligand.sdf")
        lib_path = os.path.join(root, "examples", "neuro_case_study", "screening_library.sdf")

        receptor = parse_pdb(rec_path)
        ref_lig = parse_sdf(ref_path)[0]
        library = parse_sdf(lib_path)

        pipeline = VirtualScreeningPipeline()
        result = pipeline.run(receptor, ref_lig, library)

        self.assertEqual(result.num_screened, 6)
        self.assertEqual(len(result.ranked_candidates), 6)
        self.assertGreaterEqual(result.ranked_candidates[0].consensus_score, result.ranked_candidates[-1].consensus_score)

        # Test CSV export
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            result.export_csv(tmp_path)
            self.assertTrue(os.path.exists(tmp_path))
            self.assertGreater(os.path.getsize(tmp_path), 50)
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)


if __name__ == "__main__":
    unittest.main()
