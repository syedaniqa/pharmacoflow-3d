from setuptools import setup, find_packages

setup(
    name="pharmacoflow-3d",
    version="1.0.0",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "pharmacoflow=pharmacoflow.cli:main",
        ],
    },
)
