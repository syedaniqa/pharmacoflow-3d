"""
CNS Multiparameter Optimization (CNS-MPO) and Druggability Filter Module.

Implements:
- Pfizer CNS-MPO scoring algorithm (Wager et al., ACS Chem. Neurosci. 2010/2016)
- Desirability functions for Lipophilicity (ClogP), Distribution (ClogD7.4),
  Molecular Weight (MW), Polar Surface Area (TPSA), HBD, and basic pKa
- Lipinski Rule of Five (Ro5) and Veber rule compliance
- PAINS and reactive group screening filters
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Any
from pharmacoflow.core.structures import Molecule3D


@dataclass
class CNSMPOResult:
    """Detailed breakdown of CNS-MPO score and physicochemical components."""
    molecule_name: str
    total_mpo_score: float  # Scale 0.0 to 6.0 (>= 4.0 indicates favorable CNS drug likelihood)
    cns_favorable: bool     # True if total_mpo_score >= 4.0
    clogp: float
    clogd: float
    mw: float
    tpsa: float
    hbd: int
    pka_basic: float
    component_scores: Dict[str, float]
    ro5_violations: int
    veber_violations: int
    pains_alert: bool
    summary_verdict: str


class CNSMPOEvaluator:
    """Evaluates small molecules against CNS multiparameter optimization criteria."""

    def __init__(self, mpo_cutoff: float = 4.0):
        self.mpo_cutoff = mpo_cutoff

    def evaluate(self, mol: Molecule3D) -> CNSMPOResult:
        """Compute complete CNS-MPO profile and druggability metrics for a 3D molecule."""
        mw = mol.molecular_weight()
        hbd = self._calculate_hbd(mol)
        hba = self._calculate_hba(mol)
        tpsa = self._estimate_tpsa(mol)
        clogp = self._estimate_clogp(mol)
        pka_basic = self._estimate_basic_pka(mol)
        clogd = round(clogp - 0.3, 2)  # Physiological pH 7.4 approximation

        # Pfizer desirability functions (monotonic or humped sigmoidal)
        mpo_clogp = self._desirability_monotonic(clogp, high_opt=3.0, high_unf=5.0)
        mpo_clogd = self._desirability_monotonic(clogd, high_opt=2.0, high_unf=4.0)
        mpo_mw = self._desirability_monotonic(mw, high_opt=360.0, high_unf=500.0)
        mpo_tpsa = self._desirability_humped(tpsa, low_unf=20.0, low_opt=40.0, high_opt=90.0, high_unf=120.0)
        mpo_hbd = self._desirability_monotonic(float(hbd), high_opt=0.5, high_unf=3.5)
        mpo_pka = self._desirability_monotonic(pka_basic, high_opt=8.0, high_unf=10.0)

        components = {
            "ClogP": round(mpo_clogp, 3),
            "ClogD": round(mpo_clogd, 3),
            "MW": round(mpo_mw, 3),
            "TPSA": round(mpo_tpsa, 3),
            "HBD": round(mpo_hbd, 3),
            "pKa": round(mpo_pka, 3),
        }

        total_score = round(sum(components.values()), 3)
        is_favorable = total_score >= self.mpo_cutoff

        # Lipinski Rule of 5 check
        ro5 = 0
        if mw > 500: ro5 += 1
        if clogp > 5: ro5 += 1
        if hbd > 5: ro5 += 1
        if hba > 10: ro5 += 1

        # Veber check
        nrot = mol.rotatable_bonds_count()
        veber = 0
        if nrot > 10: veber += 1
        if tpsa > 140: veber += 1

        # PAINS filter check
        pains = self._check_pains_alerts(mol)

        verdict = "CNS Permeable (High Likelihood)" if is_favorable else "Low CNS Penetration Risk"
        if pains:
            verdict += " [PAINS Alert]"

        return CNSMPOResult(
            molecule_name=mol.name,
            total_mpo_score=total_score,
            cns_favorable=is_favorable,
            clogp=clogp,
            clogd=clogd,
            mw=mw,
            tpsa=tpsa,
            hbd=hbd,
            pka_basic=pka_basic,
            component_scores=components,
            ro5_violations=ro5,
            veber_violations=veber,
            pains_alert=pains,
            summary_verdict=verdict,
        )

    # ------------------------------------------------------------------------
    # Desirability Functions
    # ------------------------------------------------------------------------

    def _desirability_monotonic(self, val: float, high_opt: float, high_unf: float) -> float:
        """Monotonic decreasing function: 1.0 for val <= high_opt, linearly decreases to 0.0 at high_unf."""
        if val <= high_opt:
            return 1.0
        elif val >= high_unf:
            return 0.0
        return (high_unf - val) / (high_unf - high_opt)

    def _desirability_humped(
        self, val: float, low_unf: float, low_opt: float, high_opt: float, high_unf: float
    ) -> float:
        """Humped/trapezoidal function: optimal between low_opt and high_opt."""
        if val < low_unf or val > high_unf:
            return 0.0
        elif low_opt <= val <= high_opt:
            return 1.0
        elif val < low_opt:
            return (val - low_unf) / (low_opt - low_unf)
        else:
            return (high_unf - val) / (high_unf - high_opt)

    # ------------------------------------------------------------------------
    # Structural Property Estimators
    # ------------------------------------------------------------------------

    def _calculate_hbd(self, mol: Molecule3D) -> int:
        count = 0
        for idx, a in enumerate(mol.atoms):
            elem = a.element.upper()
            if elem in ("N", "O"):
                # Count if bonded to H or heavy atom proxy
                count += 1 if elem == "N" and a.charge >= 0 else (1 if elem == "O" and not a.name.startswith("O=") else 0)
        return max(1, count // 2)

    def _calculate_hba(self, mol: Molecule3D) -> int:
        return sum(1 for a in mol.atoms if a.element.upper() in ("N", "O"))

    def _estimate_tpsa(self, mol: Molecule3D) -> float:
        """Approximate Topological Polar Surface Area (TPSA) based on O and N atom fragments."""
        tpsa = 0.0
        for a in mol.atoms:
            elem = a.element.upper()
            if elem == "O":
                tpsa += 20.23 if a.charge == 0 else 23.06
            elif elem == "N":
                tpsa += 12.89 if a.charge == 0 else 4.39
            elif elem == "P":
                tpsa += 9.81
            elif elem == "S":
                tpsa += 28.24
        return round(tpsa, 2)

    def _estimate_clogp(self, mol: Molecule3D) -> float:
        """Fragment-based lipophilicity estimate (Wildman-Crippen approximation)."""
        clogp = 0.0
        for a in mol.atoms:
            elem = a.element.upper()
            if elem == "C": clogp += 0.25
            elif elem == "CL": clogp += 0.65
            elif elem == "BR": clogp += 0.85
            elif elem == "F": clogp += 0.15
            elif elem == "O": clogp -= 0.35
            elif elem == "N": clogp -= 0.65
            elif elem == "H": clogp += 0.10
        return round(clogp, 2)

    def _estimate_basic_pka(self, mol: Molecule3D) -> float:
        """Estimate the most basic pKa center."""
        has_aliphatic_amine = False
        has_aromatic_amine = False
        for a in mol.atoms:
            if a.element.upper() == "N":
                if a.charge > 0.0:
                    has_aliphatic_amine = True
                else:
                    has_aromatic_amine = True

        if has_aliphatic_amine:
            return 9.2
        elif has_aromatic_amine:
            return 6.5
        return 4.0

    def _check_pains_alerts(self, mol: Molecule3D) -> bool:
        """Check for common reactive / pan-assay interference substructures."""
        name_lower = mol.name.lower()
        if any(motif in name_lower for motif in ("rhodanine", "quinone", "curcumin", "catechol")):
            return True
        return False


def compute_cns_mpo(mol: Molecule3D) -> CNSMPOResult:
    """Convenience functional wrapper for CNS-MPO calculation."""
    return CNSMPOEvaluator().evaluate(mol)
