---
name: Feature Request
about: Suggest an idea or new scientific capability for PharmacoFlow-3D
title: '[ENHANCEMENT] '
labels: enhancement
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the computational bottleneck or gap is.

**Describe the solution you'd like**
A clear description of what CADD or bioinformatics capability you would like added.

**Scientific Context / Literature Reference**
If applicable, add links, DOIs, or citations to relevant papers or benchmark methodologies.
