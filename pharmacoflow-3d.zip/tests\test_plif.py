"""
Unit tests for Protein-Ligand Interaction Fingerprints (PLIF) and Contact Detection.
"""

import unittest
from pharmacoflow.core.structures import (
    Atom3D,
    Molecule3D,
    ProteinComplex,
    Residue3D,
)
from pharmacoflow.interactions.contacts import (
    ContactDetector,
    InteractionType,
)
from pharmacoflow.interactions.plif import (
    compute_plif,
    plif_tanimoto,
)


class TestPLIF(unittest.TestCase):

    def setUp(self):
        # Receptor with ASP (acceptor/acidic) and PHE (aromatic)
        asp_atoms = [
            Atom3D("N", "N", 0.0, 0.0, 0.0),
            Atom3D("CA", "C", 1.0, 0.0, 0.0),
            Atom3D("OD1", "O", 3.0, 0.0, 0.0, charge=-0.5),
        ]
        asp_res = Residue3D("ASP", 10, "A", asp_atoms)

        phe_atoms = [
            Atom3D("N", "N", 10.0, 0.0, 0.0),
            Atom3D("CA", "C", 11.0, 0.0, 0.0),
            Atom3D("CG", "C", 12.0, 0.0, 0.0),
        ]
        phe_res = Residue3D("PHE", 20, "A", phe_atoms)

        self.receptor = ProteinComplex("Receptor1", residues=[asp_res, phe_res])

        # Ligand with donor nitrogen close to ASP OD1 (distance = 2.8 A)
        lig_atoms = [
            Atom3D("N1", "N", 3.0, 2.8, 0.0, charge=0.5),
            Atom3D("C1", "C", 4.0, 3.5, 0.0),
        ]
        self.ligand = Molecule3D("Lig1", atoms=lig_atoms)

    def test_contact_detection(self):
        detector = ContactDetector(hbond_dist_cutoff=3.5, salt_bridge_cutoff=4.0)
        contacts = detector.detect_contacts(self.receptor, self.ligand)
        self.assertGreater(len(contacts), 0)
        types = [c.interaction_type for c in contacts]
        self.assertTrue(InteractionType.HBOND_DONOR in types or InteractionType.SALT_BRIDGE in types)

    def test_plif_tanimoto_identity(self):
        fp1 = compute_plif(self.receptor, self.ligand)
        fp2 = compute_plif(self.receptor, self.ligand)
        tc = plif_tanimoto(fp1, fp2)
        self.assertAlmostEqual(tc, 1.0, places=4)


if __name__ == "__main__":
    unittest.main()
