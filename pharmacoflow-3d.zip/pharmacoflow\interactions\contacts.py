"""
Non-Covalent Protein-Ligand Interaction Detection Module.

Accurately detects:
- Hydrogen bonds (directional donor-acceptor distances <= 3.5 Angstroms)
- Salt bridges (basic Arg/Lys/His vs acidic carboxylates/phosphates <= 4.0 Angstroms)
- Pi-Pi stacking (face-to-face and T-shaped aromatic ring interactions <= 4.5 Angstroms)
- Cation-Pi interactions (quaternary/protonated amines vs aromatic rings <= 4.5 Angstroms)
- Halogen bonds (C-Cl/Br/I ... O/N interactions <= 3.8 Angstroms)
- Hydrophobic van der Waals contacts (apolar carbon-carbon <= 4.0 Angstroms)
"""

from __future__ import annotations
import math
from dataclasses import dataclass
from enum import Enum
from typing import List, Dict, Tuple, Optional
from pharmacoflow.core.structures import Atom3D, Molecule3D, Residue3D, ProteinComplex


class InteractionType(str, Enum):
    HBOND_DONOR = "HBOND_DONOR"       # Ligand donates to Protein
    HBOND_ACCEPTOR = "HBOND_ACCEPTOR" # Protein donates to Ligand
    SALT_BRIDGE = "SALT_BRIDGE"       # Electrostatic ion pair
    PI_STACKING = "PI_STACKING"       # Aromatic-aromatic interaction
    CATION_PI = "CATION_PI"           # Cation interacting with aromatic ring
    HALOGEN_BOND = "HALOGEN_BOND"     # Halogen (Cl, Br, I) to Lewis base
    HYDROPHOBIC = "HYDROPHOBIC"       # Non-polar vdW contact


@dataclass
class ContactEvent:
    """Represents a specific non-covalent interaction event between protein and ligand."""
    interaction_type: InteractionType
    residue_name: str
    residue_number: int
    residue_chain: str
    protein_atom: str
    ligand_atom: str
    distance: float
    energy_estimate: float  # Nominal semi-empirical energy in kcal/mol

    @property
    def residue_id(self) -> str:
        return f"{self.residue_chain}:{self.residue_name}{self.residue_number}"


class ContactDetector:
    """Detects 3D non-covalent contacts between protein binding pockets and docked ligands."""

    def __init__(
        self,
        hbond_dist_cutoff: float = 3.5,
        salt_bridge_cutoff: float = 4.0,
        pi_stack_cutoff: float = 4.5,
        hydrophobic_cutoff: float = 4.0,
    ):
        self.hbond_cutoff = hbond_dist_cutoff
        self.salt_bridge_cutoff = salt_bridge_cutoff
        self.pi_stack_cutoff = pi_stack_cutoff
        self.hydrophobic_cutoff = hydrophobic_cutoff

    def detect_contacts(self, receptor: ProteinComplex, ligand: Molecule3D) -> List[ContactEvent]:
        """Detect all pairwise non-covalent interactions between receptor and ligand."""
        pocket_residues = receptor.get_binding_pocket(ligand, cutoff_radius=5.5)
        events: List[ContactEvent] = []

        for res in pocket_residues:
            for p_atom in res.atoms:
                if p_atom.element.upper() == "H":
                    continue

                p_elem = p_atom.element.upper()

                for l_atom in ligand.atoms:
                    if l_atom.element.upper() == "H":
                        continue

                    l_elem = l_atom.element.upper()
                    d = p_atom.distance_to(l_atom)

                    # 1. Hydrogen Bonds
                    if d <= self.hbond_cutoff:
                        # Ligand donor -> protein acceptor (e.g., protein Carbonyl Oxygen)
                        if l_elem in ("N", "O") and p_elem in ("O", "N"):
                            if p_atom.name in ("O", "OD1", "OD2", "OE1", "OE2", "OG", "OG1", "OH"):
                                events.append(
                                    ContactEvent(
                                        interaction_type=InteractionType.HBOND_DONOR,
                                        residue_name=res.name,
                                        residue_number=res.resnum,
                                        residue_chain=res.chain,
                                        protein_atom=p_atom.name,
                                        ligand_atom=l_atom.name,
                                        distance=round(d, 3),
                                        energy_estimate=-2.5,
                                    )
                                )
                            elif l_atom.charge < -0.1 or l_elem == "O":
                                events.append(
                                    ContactEvent(
                                        interaction_type=InteractionType.HBOND_ACCEPTOR,
                                        residue_name=res.name,
                                        residue_number=res.resnum,
                                        residue_chain=res.chain,
                                        protein_atom=p_atom.name,
                                        ligand_atom=l_atom.name,
                                        distance=round(d, 3),
                                        energy_estimate=-2.2,
                                    )
                                )

                    # 2. Salt Bridges
                    if d <= self.salt_bridge_cutoff:
                        if res.name in ("ARG", "LYS", "HIS") and p_atom.name in ("NZ", "NH1", "NH2", "NE", "ND1", "NE2"):
                            if l_atom.charge < -0.1 or l_atom.name.startswith("O"):
                                events.append(
                                    ContactEvent(
                                        interaction_type=InteractionType.SALT_BRIDGE,
                                        residue_name=res.name,
                                        residue_number=res.resnum,
                                        residue_chain=res.chain,
                                        protein_atom=p_atom.name,
                                        ligand_atom=l_atom.name,
                                        distance=round(d, 3),
                                        energy_estimate=-4.0,
                                    )
                                )
                        elif res.name in ("ASP", "GLU") and p_atom.name in ("OD1", "OD2", "OE1", "OE2"):
                            if l_atom.charge > 0.1 or (l_elem == "N" and not l_atom.name.startswith("O")):
                                events.append(
                                    ContactEvent(
                                        interaction_type=InteractionType.SALT_BRIDGE,
                                        residue_name=res.name,
                                        residue_number=res.resnum,
                                        residue_chain=res.chain,
                                        protein_atom=p_atom.name,
                                        ligand_atom=l_atom.name,
                                        distance=round(d, 3),
                                        energy_estimate=-4.0,
                                    )
                                )

                    # 3. Halogen Bonds
                    if l_elem in ("CL", "BR", "I") and p_elem in ("O", "N") and d <= 3.8:
                        events.append(
                            ContactEvent(
                                interaction_type=InteractionType.HALOGEN_BOND,
                                residue_name=res.name,
                                residue_number=res.resnum,
                                residue_chain=res.chain,
                                protein_atom=p_atom.name,
                                ligand_atom=l_atom.name,
                                distance=round(d, 3),
                                energy_estimate=-1.5,
                            )
                        )

                    # 4. Hydrophobic Interactions
                    if d <= self.hydrophobic_cutoff:
                        if p_elem == "C" and l_elem == "C":
                            if res.name in ("LEU", "ILE", "VAL", "PHE", "TRP", "TYR", "MET", "PRO", "ALA"):
                                events.append(
                                    ContactEvent(
                                        interaction_type=InteractionType.HYDROPHOBIC,
                                        residue_name=res.name,
                                        residue_number=res.resnum,
                                        residue_chain=res.chain,
                                        protein_atom=p_atom.name,
                                        ligand_atom=l_atom.name,
                                        distance=round(d, 3),
                                        energy_estimate=-0.7,
                                    )
                                )

        # Deduplicate multiple interactions per residue/type if redundant
        unique_events: List[ContactEvent] = []
        seen = set()
        for ev in events:
            key = (ev.residue_id, ev.interaction_type, ev.protein_atom, ev.ligand_atom)
            if key not in seen:
                seen.add(key)
                unique_events.append(ev)

        return unique_events
