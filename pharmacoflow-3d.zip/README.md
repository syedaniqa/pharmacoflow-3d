# PharmacoFlow-3D

[![CI/CD Testing](https://github.com/syedaniqa/pharmacoflow-3d/actions/workflows/ci.yml/badge.svg)](https://github.com/syedaniqa/pharmacoflow-3d/actions)
[![Python Version](https://img.shields.io/badge/python-3.8%20%7C%203.9%20%7C%203.10%20%7C%203.11%20%7C%203.12%20%7C%203.13-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Field](https://img.shields.io/badge/Domain-CADD%20%7C%20Bioinformatics%20%7C%20Cheminformatics-purple.svg)](#)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

> **Automated Dynamic Ensemble Pharmacophore Modeling, Protein-Ligand Interaction Fingerprinting (PLIF), and CNS-MPO Consensus Screening Pipeline.**

Developed by **Syeda Aniqa Bukhari** (M.S. Bioinformatics, NUST).

---

## 🔬 Scientific Motivation & Real-World Problem

In Computer-Aided Drug Design (CADD), **High-Throughput Virtual Screening (HTVS)** plays an indispensable role in early-stage hit discovery. However, standard virtual screening workflows suffer from two major real-world bottlenecks:

1. **The Static Structure & Docking Trap (High False-Positive Rate):**
   Standard empirical docking scoring functions (e.g., AutoDock Vina, Glide, GNINA) frequently exhibit false-positive rates upwards of **80–90%**. They evaluate static steric and electrostatic complementarities while neglecting critical directional entropic constraints, hydrogen bond vectors, $\pi$-$\pi$ stacking geometry, and key catalytic interaction networks.
2. **The Blood-Brain Barrier (BBB) Penetration Deficit in Neurotherapeutics:**
   In neurodegenerative disorders—such as Spinal Muscular Atrophy with Progressive Myoclonic Epilepsy (**SMA-PME**), Amyotrophic Lateral Sclerosis (**ALS**), and Parkinson's Disease—many high-affinity *in silico* hits fail downstream *in vivo* because they possess poor physicochemical properties, high polar surface area, or substrate susceptibility to P-glycoprotein (P-gp) efflux.
3. **Proprietary Moats & Tool Fragmentation:**
   State-of-the-art 3D pharmacophore modeling suites (Phase, LigandScout, Discovery Studio) are gated behind expensive commercial software licenses, while open-source alternatives are fragmented and lack unified PLIF fingerprinting, automated consensus ranking, and standalone 3D interactive reporting.

**PharmacoFlow-3D** bridges this critical gap by delivering a modular, publication-ready, and open-source platform that unifies structure-guided 3D pharmacophore hypothesis generation, 7-bit PLIF fingerprint similarity, Pfizer CNS Multiparameter Optimization (CNS-MPO), and Pareto-optimal consensus ranking.

---

## ⚙️ Core Architecture & Pipeline

```
                              ┌────────────────────────────────────────┐
                              │  Macromolecular Target Complex (PDB)   │
                              │      + Bioactive Reference (SDF)       │
                              └───────────────────┬────────────────────┘
                                                  │
                      ┌───────────────────────────┴───────────────────────────┐
                      ▼                                                       ▼
        ┌───────────────────────────┐                           ┌───────────────────────────┐
        │   Active Site Analysis    │                           │  Receptor-Guided 3D       │
        │   & Pocket Extraction     │                           │  Pharmacophore Derivation │
        └─────────────┬─────────────┘                           └─────────────┬─────────────┘
                      │                                                       │
                      ▼                                                       ▼
        ┌───────────────────────────┐                           ┌───────────────────────────┐
        │  PLIF Contact Profiler    │                           │  Spatial Tolerance Match  │
        │  (7-Bit Per Pocket Res)   │                           │  (HBD, HBA, ARO, HYD, +/-)│
        └─────────────┬─────────────┘                           └─────────────┬─────────────┘
                      │                                                       │
                      └───────────────────────────┬───────────────────────────┘
                                                  │
                                                  ▼
                                ┌───────────────────────────────────┐
                                │   Candidate Library Screening     │
                                │   (Multi-Conformer Poses / Vina)  │
                                └─────────────────┬─────────────────┘
                                                  │
                                                  ▼
                                ┌───────────────────────────────────┐
                                │   Pfizer CNS-MPO & Druggability   │
                                │   (MW, ClogP, ClogD, TPSA, pKa)   │
                                └─────────────────┬─────────────────┘
                                                  │
                                                  ▼
                                ┌───────────────────────────────────┐
                                │  Consensus Rank Aggregator        │
                                │  • Standardized Z-Score Ranking   │
                                │  • Borda Count Summation          │
                                │  • Pareto Non-Dominated Frontier  │
                                └─────────────────┬─────────────────┘
                                                  │
                                                  ▼
                                ┌───────────────────────────────────┐
                                │   Interactive 3D WebGL Dashboard  │
                                │   CSV / JSON / PyMOL Artifacts    │
                                └───────────────────────────────────┘
```

---

## 🚀 Key Features

- **3D Structure-Guided Pharmacophore Derivation:**
  - Automated perception of Hydrogen Bond Donors (**HBD**), Acceptors (**HBA**), Aromatic Ring Centroids (**AROMATIC**), Lipophilic/Hydrophobic clusters (**HYDROPHOBIC**), and Ionizable centers (**POS** / **NEG**).
  - Spatial tolerance spheres with directional orientation vectors.
  - Generates transparent CGO sphere scripts ready to load directly in **PyMOL** (`.pml`).
- **Protein-Ligand Interaction Fingerprints (PLIF):**
  - High-resolution non-covalent contact detection: H-bonds ($d \le 3.5$ \AA), salt bridges ($d \le 4.0$ \AA), $\pi$-$\pi$ stacking ($d \le 4.5$ \AA), cation-$\pi$, halogen bonds, and hydrophobic interactions.
  - Encodes interaction networks into a 7-bit per pocket residue binary vector.
  - Tanimoto (Jaccard) similarity scoring against bioactive co-crystal references.
- **Pfizer CNS Multiparameter Optimization (CNS-MPO) & Druggability:**
  - Full implementation of the 6 Pfizer continuous desirability functions: Lipophilicity ($\text{ClogP}$), Distribution ($\text{ClogD}_{7.4}$), Molecular Weight ($\text{MW}$), Polar Surface Area ($\text{TPSA}$), H-bond donors ($\text{HBD}$), and most basic $\text{p}K_a$.
  - Generates CNS-MPO scores on a $0.0 - 6.0$ scale ($\ge 4.0$ indicates favorable CNS penetration).
  - Built-in checks for Lipinski Rule of 5, Veber criteria, and PAINS structural alerts.
- **Multi-Parametric Consensus Aggregation:**
  - Standardized Z-Score composite ranking across orthogonal metrics.
  - Borda Count summation to avoid metric skewing.
  - **Pareto Non-Dominated Sorting:** Automatically flags candidates sitting on the multi-dimensional efficiency frontier.
- **Interactive 3D WebGL Reporting:**
  - Standalone, zero-dependency HTML dashboard powered by **3Dmol.js**.
  - Interactive pocket inspection, docked ligand coordinates, colored pharmacophore spheres, and candidate property radar charts.

---

## ⚡ Quickstart

### 1. Installation
Clone the repository and install in editable mode:
```bash
git clone https://github.com/syedaniqa/pharmacoflow-3d.git
cd pharmacoflow-3d
pip install -e .
```

### 2. Run the Benchmark Case Study in 10 Seconds
Execute the built-in neurodegeneration virtual screening benchmark:
```bash
pharmacoflow quickstart
```
Or with Python:
```bash
python examples/quickstart.py
```

---

## 📊 Benchmark Case Study: *ASAH1* Catalytic Domain (SMA-PME)

The benchmark case study targets human Acid Ceramidase (*ASAH1*), the primary causal enzyme in **Spinal Muscular Atrophy with Progressive Myoclonic Epilepsy (SMA-PME)** and Farber Disease.

A diverse 6-candidate benchmark library was screened against the catalytic cleft containing residues Cys143, Asp162, Arg228, Phe310, and Leu280:

| Rank | Candidate Molecule | Consensus Score (0-100) | Docking Energy (kcal/mol) | Pharm Fitness | PLIF Tanimoto | CNS-MPO Score (0-6) | BBB Verdict | Pareto Front |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **#1** | **`PF3D-Lead-01`** | **64.44** | **-9.62** | **0.797** | **1.000** | **5.83** | **PASS [CNS]** | **★ (Optimal)** |
| **#2** | `PF3D-Hit-02` | 59.55 | -8.88 | 0.754 | 0.800 | 5.49 | PASS [CNS] | |
| **#3** | `PF3D-Control-CNS` | 56.73 | -8.25 | 0.617 | 0.800 | 5.49 | PASS [CNS] | |
| **#4** | `PF3D-Decoy-Polar` | 44.05 | -9.20 | 0.000 | 0.429 | 4.00 | Borderline | |
| **#5** | `PF3D-Analog-03` | 41.69 | -7.80 | 0.000 | 0.200 | 4.61 | PASS [CNS] | |
| **#6** | `PF3D-Negative-06` | 33.55 | -4.60 | 0.000 | 0.000 | 4.73 | Out-of-Pocket | |

> **Key Finding:** `PF3D-Decoy-Polar` achieved high docking affinity (-9.20 kcal/mol) but was rejected by pharmacophore geometric alignment and flagged for high polar surface area. In contrast, **`PF3D-Lead-01`** matched key catalytic interaction vectors, achieved perfect PLIF similarity ($T_c = 1.0$), and scored **5.83 / 6.0** on CNS-MPO, landing uniquely on the **Pareto frontier**.

---

## 💻 CLI Usage

```bash
# 1. High-Throughput Virtual Screening
pharmacoflow screen \
    --receptor examples/neuro_case_study/receptor.pdb \
    --reference examples/neuro_case_study/reference_ligand.sdf \
    --library examples/neuro_case_study/screening_library.sdf \
    --output-dir ./results \
    --tolerance 1.3 \
    --mpo-cutoff 4.0

# 2. Derive 3D Pharmacophore Model & PyMOL Script
pharmacoflow generate \
    --ligand examples/neuro_case_study/reference_ligand.sdf \
    --receptor examples/neuro_case_study/receptor.pdb \
    --output pharmacophore_model.json \
    --pymol pharmacophore_spheres.pml

# 3. Compute Protein-Ligand Interaction Fingerprints
pharmacoflow plif \
    --receptor examples/neuro_case_study/receptor.pdb \
    --ligand examples/neuro_case_study/reference_ligand.sdf

# 4. Assess CNS-MPO Druggability
pharmacoflow cns-mpo --library examples/neuro_case_study/screening_library.sdf
```

---

## 🐍 Python API Example

```python
from pharmacoflow.core.structures import parse_pdb, parse_sdf
from pharmacoflow.screening.engine import VirtualScreeningPipeline
from pharmacoflow.visualizer.html_report import generate_3d_report

# Load structures
receptor = parse_pdb("receptor.pdb")
reference_ligand = parse_sdf("reference_ligand.sdf")[0]
library = parse_sdf("candidate_library.sdf")

# Run screening pipeline
pipeline = VirtualScreeningPipeline(pharmacophore_tolerance=1.3, mpo_cutoff=4.0)
results = pipeline.run(receptor, reference_ligand, library)

# Export artifacts
results.export_csv("screening_results.csv")
generate_3d_report(results, receptor, reference_ligand, "screening_report.html")
```

---

## 🧪 Testing & Validation

The entire codebase is validated with unit tests covering parsing, geometric superposition, pharmacophore feature extraction, PLIF generation, CNS-MPO calculation, and consensus ranking:

```bash
python -m unittest discover tests
```

---

## 📂 Project Organization

```
pharmacoflow-3d/
├── .github/
│   ├── workflows/ci.yml         # GitHub Actions Automated CI/CD
│   └── ISSUE_TEMPLATE/          # Bug report & feature templates
├── docs/
│   ├── ARCHITECTURE.md          # Scientific equations, theory, and methods
│   ├── TUTORIAL.md              # Detailed end-to-end tutorial
│   └── LINKEDIN_POST.md         # Professional launch announcement
├── examples/
│   ├── neuro_case_study/        # ASAH1 active site benchmark case study
│   │   ├── receptor.pdb
│   │   ├── reference_ligand.sdf
│   │   └── screening_library.sdf
│   └── quickstart.py            # Automated demonstration script
├── pharmacoflow/
│   ├── __init__.py
│   ├── cli.py                   # Command-line interface
│   ├── core/                    # Coordinate processing, PDB/SDF parsers, RMSD, Kabsch
│   ├── pharmacophore/           # 3D feature extraction, tolerance spheres, matching
│   ├── interactions/            # Non-covalent contact detection & 7-bit PLIF
│   ├── screening/               # Consensus rank aggregator & Pfizer CNS-MPO
│   └── visualizer/              # 3Dmol.js WebGL dashboard generator
├── tests/                       # Unit tests (100% pass rate)
├── LICENSE                      # MIT License
├── pyproject.toml               # PEP 517 build configuration
├── requirements.txt             # Dependency specification
└── setup.py
```

---

## 👩‍🔬 Author & Citation

**Syeda Aniqa Bukhari**
- M.S. Bioinformatics, National University of Sciences and Technology (NUST), Islamabad.
- Specialization: Computer-Aided Drug Design (CADD), Molecular Modeling, Neurodegenerative Disorders (SMA-PME).
- Email: [saniqabukhar@gmail.com](mailto:saniqabukhar@gmail.com)
- ScholarGPS: [Syeda Aniqa Bukhari](https://scholargps.com/scholars/64598106006160/syeda-aniqa-bukhari)

If you use `PharmacoFlow-3D` in your research, please cite:

```bibtex
@software{bukhari2026pharmacoflow3d,
  author = {Bukhari, Syeda Aniqa},
  title = {PharmacoFlow-3D: Automated Dynamic Ensemble Pharmacophore Modeling, Protein-Ligand Interaction Fingerprinting (PLIF), and CNS-MPO Consensus Screening Pipeline},
  url = {https://github.com/syedaniqa/pharmacoflow-3d},
  year = {2026},
  version = {1.0.0}
}
```

---

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
