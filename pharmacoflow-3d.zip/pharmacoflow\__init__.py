"""
PharmacoFlow-3D: Automated Dynamic Ensemble Pharmacophore Modeling,
Protein-Ligand Interaction Fingerprinting (PLIF), and CNS-MPO Consensus Screening Pipeline.

Author: Syeda Aniqa Bukhari & Contributors
License: MIT
"""

__version__ = "1.0.0"
__author__ = "Syeda Aniqa Bukhari"
__email__ = "saniqabukhar@gmail.com"

from pharmacoflow.core.structures import (
    Atom3D,
    Molecule3D,
    ProteinComplex,
    parse_pdb,
    parse_sdf,
    write_sdf,
    kabsch_align,
    calculate_rmsd,
)
from pharmacoflow.pharmacophore.features import (
    PharmacophoreFeature,
    FeatureType,
    PharmacophoreModel,
)
from pharmacoflow.pharmacophore.generator import PharmacophoreGenerator
from pharmacoflow.pharmacophore.matcher import PharmacophoreMatcher, MatchResult
from pharmacoflow.interactions.plif import (
    InteractionFingerprint,
    InteractionType,
    compute_plif,
)
from pharmacoflow.screening.cns_mpo import (
    CNSMPOEvaluator,
    CNSMPOResult,
    compute_cns_mpo,
)
from pharmacoflow.screening.consensus import ConsensusScorer
from pharmacoflow.screening.engine import VirtualScreeningPipeline, ScreeningResult
from pharmacoflow.visualizer.html_report import generate_3d_report

__all__ = [
    "Atom3D",
    "Molecule3D",
    "ProteinComplex",
    "parse_pdb",
    "parse_sdf",
    "write_sdf",
    "kabsch_align",
    "calculate_rmsd",
    "PharmacophoreFeature",
    "FeatureType",
    "PharmacophoreModel",
    "PharmacophoreGenerator",
    "PharmacophoreMatcher",
    "MatchResult",
    "InteractionFingerprint",
    "InteractionType",
    "compute_plif",
    "CNSMPOEvaluator",
    "CNSMPOResult",
    "compute_cns_mpo",
    "ConsensusScorer",
    "VirtualScreeningPipeline",
    "ScreeningResult",
    "generate_3d_report",
]
