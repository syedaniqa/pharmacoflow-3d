"""
Command-Line Interface (CLI) for PharmacoFlow-3D.

Provides subcommands:
- screen: Run full high-throughput virtual screening pipeline
- generate: Derive 3D pharmacophore models from ligand or receptor-ligand complex
- plif: Compute protein-ligand interaction fingerprints
- cns-mpo: Evaluate CNS-MPO multiparameter scores and Ro5/Veber/PAINS properties
- quickstart: Execute built-in neurodegenerative case study benchmark
"""

from __future__ import annotations
import argparse
import sys
import os
from pharmacoflow.core.structures import parse_pdb, parse_sdf, write_sdf
from pharmacoflow.pharmacophore.generator import PharmacophoreGenerator
from pharmacoflow.pharmacophore.features import PharmacophoreModel
from pharmacoflow.interactions.plif import compute_plif
from pharmacoflow.screening.cns_mpo import CNSMPOEvaluator
from pharmacoflow.screening.engine import VirtualScreeningPipeline
from pharmacoflow.visualizer.html_report import generate_3d_report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pharmacoflow",
        description="PharmacoFlow-3D: Dynamic Ensemble Pharmacophore & CNS-MPO Virtual Screening Pipeline",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # Command: screen
    screen_parser = subparsers.add_parser("screen", help="Execute complete virtual screening pipeline")
    screen_parser.add_argument("--receptor", required=True, help="Receptor structure file (PDB)")
    screen_parser.add_argument("--reference", required=True, help="Bioactive reference ligand (SDF)")
    screen_parser.add_argument("--library", required=True, help="Candidate screening library (SDF)")
    screen_parser.add_argument("--output-dir", default="./results", help="Directory for output files")
    screen_parser.add_argument("--tolerance", type=float, default=1.3, help="Pharmacophore tolerance sphere radius (A)")
    screen_parser.add_argument("--mpo-cutoff", type=float, default=4.0, help="CNS-MPO desirability cutoff (default 4.0)")

    # Command: generate
    gen_parser = subparsers.add_parser("generate", help="Generate 3D pharmacophore model")
    gen_parser.add_argument("--ligand", required=True, help="Ligand structure (SDF)")
    gen_parser.add_argument("--receptor", default=None, help="Optional receptor structure (PDB) for structure-guided model")
    gen_parser.add_argument("--output", default="pharmacophore_model.json", help="Output JSON path")
    gen_parser.add_argument("--pymol", default=None, help="Optional PyMOL .pml script path")

    # Command: plif
    plif_parser = subparsers.add_parser("plif", help="Compute Protein-Ligand Interaction Fingerprints (PLIF)")
    plif_parser.add_argument("--receptor", required=True, help="Receptor PDB")
    plif_parser.add_argument("--ligand", required=True, help="Docked ligand SDF")

    # Command: cns-mpo
    mpo_parser = subparsers.add_parser("cns-mpo", help="Evaluate CNS-MPO and druggability metrics")
    mpo_parser.add_argument("--library", required=True, help="Input SDF library")

    # Command: quickstart
    subparsers.add_parser("quickstart", help="Run the built-in neurodegeneration benchmark demonstration")

    return parser


def handle_screen(args: argparse.Namespace) -> None:
    print(f"[*] Loading receptor: {args.receptor}")
    receptor = parse_pdb(args.receptor)
    print(f"[*] Loading reference ligand: {args.reference}")
    ref_ligands = parse_sdf(args.reference)
    if not ref_ligands:
        print("[!] Error: No ligand found in reference SDF.")
        sys.exit(1)
    ref_lig = ref_ligands[0]

    print(f"[*] Loading screening library: {args.library}")
    library = parse_sdf(args.library)
    print(f"    Loaded {len(library)} candidate molecules.")

    os.makedirs(args.output_dir, exist_ok=True)

    print("[*] Running PharmacoFlow-3D Screening Pipeline...")
    pipeline = VirtualScreeningPipeline(
        pharmacophore_tolerance=args.tolerance,
        mpo_cutoff=args.mpo_cutoff,
    )
    result = pipeline.run(receptor, ref_lig, library)

    csv_path = os.path.join(args.output_dir, "screening_results.csv")
    json_path = os.path.join(args.output_dir, "screening_results.json")
    html_path = os.path.join(args.output_dir, "screening_report.html")

    result.export_csv(csv_path)
    result.export_json(json_path)
    generate_3d_report(result, receptor, ref_lig, html_path)

    print("\n[+] Screening Finished Successfully!")
    print(f"    - Results CSV: {csv_path}")
    print(f"    - Campaign JSON: {json_path}")
    print(f"    - Interactive 3D HTML Report: {html_path}")
    print("\nTop 3 Ranked Hits:")
    for item in result.ranked_candidates[:3]:
        mpo = result.mpo_profiles.get(item.name)
        cns_str = "PASS" if mpo and mpo.cns_favorable else "FAIL"
        print(f"  #{item.rank} {item.name:<20} | Score: {item.consensus_score:<5.1f} | Dock: {item.docking_score:<5.1f} | MPO: {item.cns_mpo:<4.2f} [{cns_str}]")


def handle_generate(args: argparse.Namespace) -> None:
    ligands = parse_sdf(args.ligand)
    if not ligands:
        print("[!] No ligand found in SDF.")
        return
    lig = ligands[0]
    gen = PharmacophoreGenerator()

    if args.receptor:
        rec = parse_pdb(args.receptor)
        model = gen.generate_receptor_guided(rec, lig, model_name=f"{lig.name}_Model")
    else:
        model = gen.generate_from_ligand(lig, model_name=f"{lig.name}_Model")

    model.save_json(args.output)
    print(f"[+] Saved {model.num_features}-feature model to {args.output}")

    if args.pymol:
        model.export_pymol_script(args.pymol)
        print(f"[+] Exported PyMOL script to {args.pymol}")


def handle_plif(args: argparse.Namespace) -> None:
    rec = parse_pdb(args.receptor)
    ligands = parse_sdf(args.ligand)
    if not ligands:
        return
    lig = ligands[0]
    fp = compute_plif(rec, lig)
    print(f"[+] Detected {len(fp.contacts)} non-covalent contacts across {len(fp.residue_ids)} residues.")
    for c in fp.contacts:
        print(f"    {c.residue_id:<12} {c.interaction_type.value:<16} Atom: {c.protein_atom} <-> {c.ligand_atom} ({c.distance:.2f} A)")


def handle_cns_mpo(args: argparse.Namespace) -> None:
    molecules = parse_sdf(args.library)
    evaluator = CNSMPOEvaluator()
    print(f"{'Molecule':<20} {'MPO':<6} {'Verdict':<28} {'MW':<7} {'ClogP':<7} {'TPSA':<7} {'Ro5'}")
    print("-" * 85)
    for m in molecules:
        res = evaluator.evaluate(m)
        print(f"{m.name:<20} {res.total_mpo_score:<6.2f} {res.summary_verdict:<28} {res.mw:<7.1f} {res.clogp:<7.2f} {res.tpsa:<7.1f} {res.ro5_violations}")


def handle_quickstart() -> None:
    # Run the neurodegeneration demo
    from examples.quickstart import run_demo
    run_demo()


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "screen":
        handle_screen(args)
    elif args.command == "generate":
        handle_generate(args)
    elif args.command == "plif":
        handle_plif(args)
    elif args.command == "cns-mpo":
        handle_cns_mpo(args)
    elif args.command == "quickstart":
        handle_quickstart()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
