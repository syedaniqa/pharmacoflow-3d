"""
3D Spatial Pharmacophore Matching Algorithm and Fitness Scoring.

Implements:
- Subgraph distance matching between hypothesis feature spheres and candidate molecule
- Support for strict full-match and partial-match (N-1) modes
- Gaussian-weighted spatial fitness scoring:
  Fitness = (1 / Sum(w_i)) * Sum_i [ w_i * (1 - (d_i / tol_i)^2) ]
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Any
from pharmacoflow.core.structures import Molecule3D
from pharmacoflow.pharmacophore.features import (
    PharmacophoreModel,
    PharmacophoreFeature,
    FeatureType,
)
from pharmacoflow.pharmacophore.generator import PharmacophoreGenerator


@dataclass
class MatchResult:
    """Detailed outcome of screening a molecule against a pharmacophore model."""
    molecule_name: str
    is_match: bool
    matched_features: int
    total_features: int
    fitness_score: float  # 0.0 to 1.0 (1.0 = perfect spatial match)
    rms_distance: float   # RMS spatial deviation across matched features in Angstroms
    matched_pairs: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def coverage(self) -> float:
        return self.matched_features / self.total_features if self.total_features > 0 else 0.0


class PharmacophoreMatcher:
    """Evaluates candidate 3D molecules against PharmacophoreModel hypotheses."""

    def __init__(self, partial_match_allowed: bool = False, min_match_ratio: float = 0.75):
        self.partial_match_allowed = partial_match_allowed
        self.min_match_ratio = min_match_ratio
        self._generator = PharmacophoreGenerator()

    def match(self, model: PharmacophoreModel, candidate: Molecule3D) -> MatchResult:
        """Score candidate molecule against the target pharmacophore model."""
        if not model.features:
            return MatchResult(
                molecule_name=candidate.name,
                is_match=True,
                matched_features=0,
                total_features=0,
                fitness_score=1.0,
                rms_distance=0.0,
            )

        # Extract features present on candidate molecule
        cand_model = self._generator.generate_from_ligand(candidate, model_name=candidate.name)

        matched_pairs: List[Dict[str, Any]] = []
        used_cand_features = set()
        sq_deviations: List[float] = []
        weighted_fitness_sum = 0.0
        total_weight_matched = 0.0

        for q_feat in model.features:
            best_cand_idx = None
            min_dist = float("inf")

            for c_idx, c_feat in enumerate(cand_model.features):
                if c_idx in used_cand_features:
                    continue
                # Compatibility check
                if self._are_features_compatible(q_feat.feature_type, c_feat.feature_type):
                    dist = q_feat.distance_to(c_feat.coords)
                    if dist <= q_feat.tolerance and dist < min_dist:
                        min_dist = dist
                        best_cand_idx = c_idx

            if best_cand_idx is not None:
                used_cand_features.add(best_cand_idx)
                sq_deviations.append(min_dist * min_dist)
                # Fitness contribution
                penalty = (min_dist / q_feat.tolerance) ** 2
                score_contrib = max(0.0, 1.0 - penalty)
                weighted_fitness_sum += q_feat.weight * score_contrib
                total_weight_matched += q_feat.weight

                matched_pairs.append({
                    "model_feature": q_feat.label or q_feat.feature_type.value,
                    "target_coords": q_feat.coords,
                    "candidate_coords": cand_model.features[best_cand_idx].coords,
                    "distance": round(min_dist, 3),
                    "tolerance": q_feat.tolerance,
                })

        num_matched = len(matched_pairs)
        total_feats = len(model.features)
        match_ratio = num_matched / total_feats if total_feats > 0 else 0.0

        is_match = (num_matched == total_feats) if not self.partial_match_allowed else (match_ratio >= self.min_match_ratio)

        final_fitness = 0.0
        if is_match and total_weight_matched > 0:
            final_fitness = round(weighted_fitness_sum / sum(f.weight for f in model.features), 4)

        rms_dev = math.sqrt(sum(sq_deviations) / len(sq_deviations)) if sq_deviations else 999.0

        return MatchResult(
            molecule_name=candidate.name,
            is_match=is_match,
            matched_features=num_matched,
            total_features=total_feats,
            fitness_score=final_fitness,
            rms_distance=round(rms_dev, 3),
            matched_pairs=matched_pairs,
        )

    def _are_features_compatible(self, t1: FeatureType, t2: FeatureType) -> bool:
        if t1 == t2:
            return True
        # Allow cross-tolerance for charge-assisted features
        if t1 == FeatureType.POS_IONIZABLE and t2 == FeatureType.HBD:
            return True
        if t1 == FeatureType.NEG_IONIZABLE and t2 == FeatureType.HBA:
            return True
        return False
