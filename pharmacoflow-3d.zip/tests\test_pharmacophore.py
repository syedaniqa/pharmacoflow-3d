"""
Unit tests for 3D Pharmacophore Feature Generation, Tolerance Spheres, and Matching.
"""

import unittest
import tempfile
import os
from pharmacoflow.core.structures import Atom3D, Bond, Molecule3D
from pharmacoflow.pharmacophore.features import (
    PharmacophoreFeature,
    FeatureType,
    PharmacophoreModel,
)
from pharmacoflow.pharmacophore.generator import PharmacophoreGenerator
from pharmacoflow.pharmacophore.matcher import PharmacophoreMatcher


class TestPharmacophore(unittest.TestCase):

    def setUp(self):
        # Build simple benzene ring (aromatic)
        atoms = [
            Atom3D("C1", "C", 0.0, 1.4, 0.0),
            Atom3D("C2", "C", 1.2, 0.7, 0.0),
            Atom3D("C3", "C", 1.2, -0.7, 0.0),
            Atom3D("C4", "C", 0.0, -1.4, 0.0),
            Atom3D("C5", "C", -1.2, -0.7, 0.0),
            Atom3D("C6", "C", -1.2, 0.7, 0.0),
            Atom3D("O1", "O", 2.4, 1.4, 0.0),  # HBA
        ]
        bonds = [
            Bond(0, 1, 2), Bond(1, 2, 1), Bond(2, 3, 2),
            Bond(3, 4, 1), Bond(4, 5, 2), Bond(5, 0, 1),
            Bond(1, 6, 1),
        ]
        self.ligand = Molecule3D(name="PhenolDerivative", atoms=atoms, bonds=bonds)

    def test_pharmacophore_generation(self):
        gen = PharmacophoreGenerator(tolerance=1.3)
        model = gen.generate_from_ligand(self.ligand, model_name="TestPhenol")
        types = [f.feature_type for f in model.features]
        self.assertIn(FeatureType.AROMATIC, types)
        self.assertIn(FeatureType.HBA, types)

    def test_pharmacophore_json_serialization(self):
        feat = PharmacophoreFeature(
            feature_type=FeatureType.HBD,
            x=1.0, y=2.0, z=3.0, tolerance=1.5, label="TestHBD"
        )
        model = PharmacophoreModel(name="ModelA", features=[feat])
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            model.save_json(tmp_path)
            loaded = PharmacophoreModel.load_json(tmp_path)
            self.assertEqual(loaded.name, "ModelA")
            self.assertEqual(len(loaded.features), 1)
            self.assertEqual(loaded.features[0].feature_type, FeatureType.HBD)
            self.assertAlmostEqual(loaded.features[0].x, 1.0)
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    def test_pharmacophore_matching(self):
        gen = PharmacophoreGenerator(tolerance=1.5)
        model = gen.generate_from_ligand(self.ligand, model_name="QueryModel")

        matcher = PharmacophoreMatcher(partial_match_allowed=True, min_match_ratio=0.5)
        res = matcher.match(model, self.ligand)
        self.assertTrue(res.is_match)
        self.assertGreater(res.fitness_score, 0.8)
        self.assertLess(res.rms_distance, 0.5)


if __name__ == "__main__":
    unittest.main()
