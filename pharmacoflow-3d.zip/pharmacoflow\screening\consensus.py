"""
Multi-Parametric Consensus Scoring and Pareto Rank Aggregation Module.

Combines:
- Docking Binding Free Energy (kcal/mol)
- 3D Pharmacophore Spatial Fitness Score
- Protein-Ligand Interaction Fingerprint (PLIF) Tanimoto Similarity
- CNS Multiparameter Optimization (CNS-MPO) Druggability Score

Methods:
- Z-Score Weighted Normalization
- Borda Count Rank Aggregation
- Pareto Non-Dominated Frontier Selection
"""

from __future__ import annotations
import math
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple


@dataclass
class CandidateScoreRow:
    """Input score container for a single screened ligand pose."""
    name: str
    docking_score: float      # Lower is better (e.g. -9.5 kcal/mol)
    pharmacophore_fitness: float  # Higher is better (0.0 to 1.0)
    plif_similarity: float        # Higher is better (0.0 to 1.0)
    cns_mpo: float                # Higher is better (0.0 to 6.0)
    extra_props: Dict[str, Any]


@dataclass
class ConsensusRankedItem:
    """Consensus-evaluated screening candidate with multi-metric rankings."""
    rank: int
    name: str
    consensus_score: float
    borda_rank: int
    is_pareto_front: bool
    docking_score: float
    pharmacophore_fitness: float
    plif_similarity: float
    cns_mpo: float
    z_score: float


class ConsensusScorer:
    """Aggregates orthogonal CADD evaluation metrics into unified consensus rankings."""

    def __init__(
        self,
        weight_docking: float = 0.30,
        weight_pharmacophore: float = 0.30,
        weight_plif: float = 0.20,
        weight_cns_mpo: float = 0.20,
    ):
        self.w_dock = weight_docking
        self.w_pharm = weight_pharmacophore
        self.w_plif = weight_plif
        self.w_mpo = weight_cns_mpo

    def rank(self, candidates: List[CandidateScoreRow]) -> List[ConsensusRankedItem]:
        """Rank candidates across all orthogonal scoring criteria."""
        n = len(candidates)
        if n == 0:
            return []

        # 1. Compute Individual Rankings for Borda Count
        sorted_by_dock = sorted(range(n), key=lambda i: candidates[i].docking_score)  # Ascending (more negative = better)
        sorted_by_pharm = sorted(range(n), key=lambda i: candidates[i].pharmacophore_fitness, reverse=True)
        sorted_by_plif = sorted(range(n), key=lambda i: candidates[i].plif_similarity, reverse=True)
        sorted_by_mpo = sorted(range(n), key=lambda i: candidates[i].cns_mpo, reverse=True)

        rank_dock = {idx: r + 1 for r, idx in enumerate(sorted_by_dock)}
        rank_pharm = {idx: r + 1 for r, idx in enumerate(sorted_by_pharm)}
        rank_plif = {idx: r + 1 for r, idx in enumerate(sorted_by_plif)}
        rank_mpo = {idx: r + 1 for r, idx in enumerate(sorted_by_mpo)}

        borda_sums = {
            i: rank_dock[i] + rank_pharm[i] + rank_plif[i] + rank_mpo[i]
            for i in range(n)
        }

        # 2. Compute Z-Scores
        mean_d = sum(c.docking_score for c in candidates) / n
        std_d = math.sqrt(sum((c.docking_score - mean_d) ** 2 for c in candidates) / n) or 1.0

        mean_p = sum(c.pharmacophore_fitness for c in candidates) / n
        std_p = math.sqrt(sum((c.pharmacophore_fitness - mean_p) ** 2 for c in candidates) / n) or 1.0

        mean_l = sum(c.plif_similarity for c in candidates) / n
        std_l = math.sqrt(sum((c.plif_similarity - mean_l) ** 2 for c in candidates) / n) or 1.0

        mean_m = sum(c.cns_mpo for c in candidates) / n
        std_m = math.sqrt(sum((c.cns_mpo - mean_m) ** 2 for c in candidates) / n) or 1.0

        z_scores: Dict[int, float] = {}
        for i, c in enumerate(candidates):
            z_d = -(c.docking_score - mean_d) / std_d  # Invert so more negative docking is positive z
            z_p = (c.pharmacophore_fitness - mean_p) / std_p
            z_l = (c.plif_similarity - mean_l) / std_l
            z_m = (c.cns_mpo - mean_m) / std_m

            z_total = (self.w_dock * z_d) + (self.w_pharm * z_p) + (self.w_plif * z_l) + (self.w_mpo * z_m)
            z_scores[i] = round(z_total, 3)

        # 3. Pareto Frontier Detection (Non-dominated sorting)
        pareto_flags = self._find_pareto_front(candidates)

        # Combine into results
        items: List[ConsensusRankedItem] = []
        for i, c in enumerate(candidates):
            # Normalised composite score (0 to 100)
            comp_score = round(50.0 + (z_scores[i] * 12.5), 2)
            items.append(
                ConsensusRankedItem(
                    rank=0,
                    name=c.name,
                    consensus_score=comp_score,
                    borda_rank=borda_sums[i],
                    is_pareto_front=pareto_flags[i],
                    docking_score=c.docking_score,
                    pharmacophore_fitness=c.pharmacophore_fitness,
                    plif_similarity=c.plif_similarity,
                    cns_mpo=c.cns_mpo,
                    z_score=z_scores[i],
                )
            )

        # Final ordering by composite score descending
        items.sort(key=lambda x: (x.consensus_score, -x.borda_rank), reverse=True)
        for r, item in enumerate(items):
            item.rank = r + 1

        return items

    def _find_pareto_front(self, candidates: List[CandidateScoreRow]) -> List[bool]:
        """Identify non-dominated solutions across [docking, pharm, plif, mpo]."""
        n = len(candidates)
        is_pareto = [True] * n

        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                # Does j dominate i?
                # j dominates i if j is at least as good in all and strictly better in at least one
                c_i = candidates[i]
                c_j = candidates[j]

                better_or_equal = (
                    c_j.docking_score <= c_i.docking_score
                    and c_j.pharmacophore_fitness >= c_i.pharmacophore_fitness
                    and c_j.plif_similarity >= c_i.plif_similarity
                    and c_j.cns_mpo >= c_i.cns_mpo
                )
                strictly_better = (
                    c_j.docking_score < c_i.docking_score
                    or c_j.pharmacophore_fitness > c_i.pharmacophore_fitness
                    or c_j.plif_similarity > c_i.plif_similarity
                    or c_j.cns_mpo > c_i.cns_mpo
                )

                if better_or_equal and strictly_better:
                    is_pareto[i] = False
                    break

        return is_pareto
