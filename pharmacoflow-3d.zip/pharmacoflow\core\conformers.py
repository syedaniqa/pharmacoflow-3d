"""
Conformer Ensemble Analysis, RMSD Clustering, and Thermodynamic Weighting.

Implements:
- RMSD distance matrix generation across multi-conformer ensembles
- Butina/Leader-Follower centroid clustering for docking pose diversity
- Boltzmann population weighting based on docking binding affinities (kcal/mol)
"""

from __future__ import annotations
import math
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
from pharmacoflow.core.structures import Molecule3D, calculate_rmsd


@dataclass
class ClusteredEnsemble:
    """Represents a set of clustered conformers with their centroids and weights."""
    centroids: List[Molecule3D]
    clusters: Dict[int, List[Molecule3D]]
    weights: Dict[int, float]
    rmsd_cutoff: float


def compute_rmsd_matrix(molecules: List[Molecule3D]) -> List[List[float]]:
    """Compute an N x N pairwise RMSD matrix between conformers with identical atom order."""
    n = len(molecules)
    matrix = [[0.0] * n for _ in range(n)]
    coords_list = [[a.coords for a in m.atoms if a.element.upper() != "H"] for m in molecules]

    for i in range(n):
        for j in range(i + 1, n):
            try:
                r = calculate_rmsd(coords_list[i], coords_list[j])
            except ValueError:
                r = 999.0
            matrix[i][j] = r
            matrix[j][i] = r
    return matrix


def cluster_conformers(
    molecules: List[Molecule3D],
    rmsd_threshold: float = 1.5,
    energy_property_key: str = "docking_score"
) -> ClusteredEnsemble:
    """
    Cluster a library or ensemble of 3D ligand poses using a greedy Butina-style algorithm.
    Picks the pose with highest neighbor count as cluster centroid.
    """
    n = len(molecules)
    if n == 0:
        return ClusteredEnsemble(centroids=[], clusters={}, weights={}, rmsd_cutoff=rmsd_threshold)

    matrix = compute_rmsd_matrix(molecules)
    neighbors = {i: [j for j in range(n) if matrix[i][j] <= rmsd_threshold] for i in range(n)}

    unassigned = set(range(n))
    cluster_map: Dict[int, List[Molecule3D]] = {}
    centroids: List[Molecule3D] = []
    cluster_idx = 0

    while unassigned:
        # Find index with most unassigned neighbors
        best_cand = None
        best_count = -1
        for i in unassigned:
            cnt = sum(1 for nb in neighbors[i] if nb in unassigned)
            if cnt > best_count:
                best_count = cnt
                best_cand = i

        if best_cand is None:
            break

        cluster_members_idx = [nb for nb in neighbors[best_cand] if nb in unassigned]
        unassigned.difference_update(cluster_members_idx)

        cluster_map[cluster_idx] = [molecules[idx] for idx in cluster_members_idx]
        centroids.append(molecules[best_cand])
        cluster_idx += 1

    # Calculate Boltzmann weights if energy property exists
    # w_i = exp(-dG / RT), with RT = 0.593 kcal/mol at 298.15K
    RT = 0.593
    energies: List[float] = []
    for cent in centroids:
        val = cent.properties.get(energy_property_key)
        try:
            energies.append(float(val))
        except (TypeError, ValueError):
            energies.append(-7.0)  # default nominal binding energy

    min_e = min(energies) if energies else 0.0
    boltz_factors = [math.exp(-(e - min_e) / RT) for e in energies]
    z_sum = sum(boltz_factors) or 1.0
    weights = {i: boltz_factors[i] / z_sum for i in range(len(centroids))}

    return ClusteredEnsemble(
        centroids=centroids,
        clusters=cluster_map,
        weights=weights,
        rmsd_cutoff=rmsd_threshold
    )
