"""
Unit tests for CNS Multiparameter Optimization (CNS-MPO) and Druggability Filters.
"""

import unittest
from pharmacoflow.core.structures import Atom3D, Molecule3D
from pharmacoflow.screening.cns_mpo import CNSMPOEvaluator, compute_cns_mpo


class TestCNSMPO(unittest.TestCase):

    def test_cns_mpo_favorable_drug(self):
        # Build small CNS drug proxy: low MW (~250), moderate ClogP, low TPSA
        atoms = [
            Atom3D("C1", "C", 0.0, 0.0, 0.0),
            Atom3D("C2", "C", 1.4, 0.0, 0.0),
            Atom3D("C3", "C", 2.1, 1.2, 0.0),
            Atom3D("C4", "C", 1.4, 2.4, 0.0),
            Atom3D("C5", "C", 0.0, 2.4, 0.0),
            Atom3D("C6", "C", -0.7, 1.2, 0.0),
            Atom3D("N1", "N", 3.5, 1.2, 0.0),
            Atom3D("C7", "C", 4.2, 2.4, 0.0),
            Atom3D("F1", "F", -2.0, 1.2, 0.0),
        ]
        mol = Molecule3D("CNS_Favorable_Candidate", atoms=atoms)
        evaluator = CNSMPOEvaluator(mpo_cutoff=4.0)
        res = evaluator.evaluate(mol)

        self.assertGreaterEqual(res.total_mpo_score, 4.0)
        self.assertTrue(res.cns_favorable)
        self.assertEqual(res.ro5_violations, 0)
        self.assertFalse(res.pains_alert)

    def test_pains_alert_detection(self):
        mol = Molecule3D("Curcumin_Analog", atoms=[Atom3D("C1", "C", 0.0, 0.0, 0.0)])
        res = compute_cns_mpo(mol)
        self.assertTrue(res.pains_alert)


if __name__ == "__main__":
    unittest.main()
