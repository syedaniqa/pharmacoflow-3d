"""
End-to-End High-Throughput Virtual Screening Pipeline Engine.

Orchestrates:
1. Receptor preparation and reference co-crystal interaction profiling
2. Structure-based pharmacophore model derivation
3. Multi-conformer candidate library screening and spatial fitness scoring
4. Target-specific PLIF similarity scoring against bioactive reference
5. CNS-MPO and pharmacokinetic property evaluation
6. Multi-parametric consensus ranking (Z-score, Borda, Pareto frontier)
7. Exporting structured reports (CSV, JSON, SDF, and interactive 3D HTML)
"""

from __future__ import annotations
import csv
import json
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from pharmacoflow.core.structures import (
    ProteinComplex,
    Molecule3D,
    parse_pdb,
    parse_sdf,
    write_sdf,
)
from pharmacoflow.pharmacophore.features import PharmacophoreModel
from pharmacoflow.pharmacophore.generator import PharmacophoreGenerator
from pharmacoflow.pharmacophore.matcher import PharmacophoreMatcher, MatchResult
from pharmacoflow.interactions.plif import (
    InteractionFingerprint,
    compute_plif,
    plif_tanimoto,
)
from pharmacoflow.screening.cns_mpo import CNSMPOEvaluator, CNSMPOResult
from pharmacoflow.screening.consensus import (
    ConsensusScorer,
    CandidateScoreRow,
    ConsensusRankedItem,
)


@dataclass
class ScreeningResult:
    """Complete summary of an executed virtual screening campaign."""
    receptor_name: str
    reference_ligand_name: str
    num_screened: int
    num_pharmacophore_hits: int
    pharmacophore_model: PharmacophoreModel
    ranked_candidates: List[ConsensusRankedItem]
    mpo_profiles: Dict[str, CNSMPOResult]
    match_results: Dict[str, MatchResult]
    plif_profiles: Dict[str, InteractionFingerprint]

    def export_csv(self, filepath: str) -> None:
        """Export ranked candidates and properties to CSV."""
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "Rank",
                "Molecule",
                "Consensus_Score",
                "Docking_Energy_kcal_mol",
                "Pharm_Fitness",
                "PLIF_Similarity",
                "CNS_MPO",
                "CNS_Favorable",
                "Pareto_Frontier",
                "MW",
                "ClogP",
                "TPSA",
                "Ro5_Violations",
            ])
            for item in self.ranked_candidates:
                mpo = self.mpo_profiles.get(item.name)
                writer.writerow([
                    item.rank,
                    item.name,
                    item.consensus_score,
                    item.docking_score,
                    item.pharmacophore_fitness,
                    item.plif_similarity,
                    item.cns_mpo,
                    "YES" if mpo and mpo.cns_favorable else "NO",
                    "YES" if item.is_pareto_front else "NO",
                    mpo.mw if mpo else "N/A",
                    mpo.clogp if mpo else "N/A",
                    mpo.tpsa if mpo else "N/A",
                    mpo.ro5_violations if mpo else "N/A",
                ])

    def export_json(self, filepath: str) -> None:
        """Export full campaign data to structured JSON."""
        data = {
            "receptor": self.receptor_name,
            "reference_ligand": self.reference_ligand_name,
            "total_screened": self.num_screened,
            "pharmacophore_hits": self.num_pharmacophore_hits,
            "pharmacophore_model": self.pharmacophore_model.to_dict(),
            "ranked_hits": [
                {
                    "rank": item.rank,
                    "name": item.name,
                    "consensus_score": item.consensus_score,
                    "docking_score": item.docking_score,
                    "pharmacophore_fitness": item.pharmacophore_fitness,
                    "plif_similarity": item.plif_similarity,
                    "cns_mpo": item.cns_mpo,
                    "is_pareto": item.is_pareto_front,
                }
                for item in self.ranked_candidates
            ],
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)


class VirtualScreeningPipeline:
    """Configurable pipeline runner for automated structure-based virtual screening."""

    def __init__(
        self,
        pharmacophore_tolerance: float = 1.3,
        partial_match_allowed: bool = True,
        min_match_ratio: float = 0.60,
        mpo_cutoff: float = 4.0,
    ):
        self.generator = PharmacophoreGenerator(tolerance=pharmacophore_tolerance)
        self.matcher = PharmacophoreMatcher(
            partial_match_allowed=partial_match_allowed,
            min_match_ratio=min_match_ratio,
        )
        self.mpo_evaluator = CNSMPOEvaluator(mpo_cutoff=mpo_cutoff)
        self.consensus_scorer = ConsensusScorer()

    def run(
        self,
        receptor: ProteinComplex,
        reference_ligand: Molecule3D,
        library: List[Molecule3D],
        custom_model: Optional[PharmacophoreModel] = None,
    ) -> ScreeningResult:
        """Execute full screening campaign against candidate small-molecule library."""
        # 1. Generate or use Pharmacophore Model
        if custom_model is not None:
            pharm_model = custom_model
        else:
            pharm_model = self.generator.generate_receptor_guided(
                receptor=receptor,
                ligand=reference_ligand,
                model_name=f"{receptor.name}_StructureGuided",
            )

        # 2. Reference PLIF Fingerprint
        ref_plif = compute_plif(receptor, reference_ligand)
        fixed_residues = ref_plif.residue_ids

        # 3. Screen Library
        score_rows: List[CandidateScoreRow] = []
        mpo_map: Dict[str, CNSMPOResult] = {}
        match_map: Dict[str, MatchResult] = {}
        plif_map: Dict[str, InteractionFingerprint] = {}
        pharm_hits_count = 0

        for mol in library:
            # Pharmacophore matching
            m_res = self.matcher.match(pharm_model, mol)
            match_map[mol.name] = m_res
            if m_res.is_match:
                pharm_hits_count += 1

            # PLIF calculation
            cand_plif = compute_plif(receptor, mol, fixed_residue_ids=fixed_residues)
            plif_map[mol.name] = cand_plif
            sim = plif_tanimoto(ref_plif, cand_plif)

            # CNS-MPO calculation
            mpo_res = self.mpo_evaluator.evaluate(mol)
            mpo_map[mol.name] = mpo_res

            # Docking score from properties or fallback
            dock_score = -7.0
            if "docking_score" in mol.properties:
                try:
                    dock_score = float(mol.properties["docking_score"])
                except (ValueError, TypeError):
                    dock_score = -7.0

            score_rows.append(
                CandidateScoreRow(
                    name=mol.name,
                    docking_score=dock_score,
                    pharmacophore_fitness=m_res.fitness_score,
                    plif_similarity=sim,
                    cns_mpo=mpo_res.total_mpo_score,
                    extra_props=mol.properties,
                )
            )

        # 4. Multi-Parametric Consensus Scoring
        ranked_items = self.consensus_scorer.rank(score_rows)

        return ScreeningResult(
            receptor_name=receptor.name,
            reference_ligand_name=reference_ligand.name,
            num_screened=len(library),
            num_pharmacophore_hits=pharm_hits_count,
            pharmacophore_model=pharm_model,
            ranked_candidates=ranked_items,
            mpo_profiles=mpo_map,
            match_results=match_map,
            plif_profiles=plif_map,
        )
