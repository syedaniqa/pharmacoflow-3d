"""
Automated 3D Pharmacophore Hypothesis Generation from Ligands and Receptor Complexes.

Features:
- Chemical perception of donors, acceptors, aromatics, lipophiles, and charges
- Receptor-guided filtering (retains pharmacophoric features interacting with pocket residues)
- Directional vector calculation for H-bonds and aromatic ring planes
- Ensemble consensus feature generation across multi-conformer docking poses
"""

from __future__ import annotations
import math
from typing import List, Dict, Tuple, Optional, Set
from pharmacoflow.core.structures import Atom3D, Molecule3D, ProteinComplex, Residue3D
from pharmacoflow.pharmacophore.features import (
    PharmacophoreFeature,
    FeatureType,
    PharmacophoreModel,
)


class PharmacophoreGenerator:
    """Generates 3D pharmacophore hypotheses from ligands and protein complexes."""

    def __init__(self, tolerance: float = 1.2):
        self.default_tolerance = tolerance

    def generate_from_ligand(self, ligand: Molecule3D, model_name: str = "LigandBasedModel") -> PharmacophoreModel:
        """Derive direct ligand-based 3D pharmacophore hypothesis."""
        features: List[PharmacophoreFeature] = []

        # 1. Detect Aromatic Rings
        rings = self._find_rings(ligand)
        for ring_indices in rings:
            if self._is_aromatic_ring(ligand, ring_indices):
                centroid = self._calculate_centroid([ligand.atoms[i] for i in ring_indices])
                normal = self._calculate_ring_normal(ligand, ring_indices)
                features.append(
                    PharmacophoreFeature(
                        feature_type=FeatureType.AROMATIC,
                        x=centroid[0],
                        y=centroid[1],
                        z=centroid[2],
                        tolerance=self.default_tolerance,
                        vector=normal,
                        label=f"Aromatic_{len(features)+1}",
                    )
                )

        # 2. Donors, Acceptors, Charges, Hydrophobics
        for idx, atom in enumerate(ligand.atoms):
            elem = atom.element.strip().upper()
            if elem == "H":
                continue

            # Check HBD (N or O bonded to H or basic heteroatoms)
            if self._is_hbd(ligand, idx):
                features.append(
                    PharmacophoreFeature(
                        feature_type=FeatureType.HBD,
                        x=atom.x,
                        y=atom.y,
                        z=atom.z,
                        tolerance=self.default_tolerance,
                        label=f"HBD_{atom.name}",
                    )
                )

            # Check HBA (N or O with lone pairs)
            if self._is_hba(ligand, idx):
                features.append(
                    PharmacophoreFeature(
                        feature_type=FeatureType.HBA,
                        x=atom.x,
                        y=atom.y,
                        z=atom.z,
                        tolerance=self.default_tolerance,
                        label=f"HBA_{atom.name}",
                    )
                )

            # Check Positive Ionizable (Amine / basic nitrogen)
            if self._is_pos_ionizable(ligand, idx):
                features.append(
                    PharmacophoreFeature(
                        feature_type=FeatureType.POS_IONIZABLE,
                        x=atom.x,
                        y=atom.y,
                        z=atom.z,
                        tolerance=1.5,
                        label=f"PosIon_{atom.name}",
                    )
                )

            # Check Negative Ionizable (Carboxylate / acidic oxygen)
            if self._is_neg_ionizable(ligand, idx):
                features.append(
                    PharmacophoreFeature(
                        feature_type=FeatureType.NEG_IONIZABLE,
                        x=atom.x,
                        y=atom.y,
                        z=atom.z,
                        tolerance=1.5,
                        label=f"NegIon_{atom.name}",
                    )
                )

            # Check Hydrophobic / Lipophilic Center (Aliphatic carbon clusters)
            if self._is_lipophilic_carbon(ligand, idx):
                features.append(
                    PharmacophoreFeature(
                        feature_type=FeatureType.HYDROPHOBIC,
                        x=atom.x,
                        y=atom.y,
                        z=atom.z,
                        tolerance=1.4,
                        label=f"Hyd_{atom.name}",
                    )
                )

        return PharmacophoreModel(
            name=model_name,
            features=features,
            metadata={"source_ligand": ligand.name, "num_atoms": len(ligand.atoms)},
        )

    def generate_receptor_guided(
        self,
        receptor: ProteinComplex,
        ligand: Molecule3D,
        cutoff_contact: float = 4.0,
        model_name: str = "StructureBasedModel",
    ) -> PharmacophoreModel:
        """
        Derive structure-based pharmacophore model by keeping only features
        that form direct contacts with binding site residues.
        """
        raw_model = self.generate_from_ligand(ligand, model_name=model_name)
        pocket_residues = receptor.get_binding_pocket(ligand, cutoff_radius=cutoff_contact + 1.5)

        filtered_features: List[PharmacophoreFeature] = []

        for feat in raw_model.features:
            interacting_res = self._find_complementary_residue(feat, pocket_residues, cutoff_contact)
            if interacting_res:
                feat.residue_partner = f"{interacting_res.name}{interacting_res.resnum}"
                feat.weight = 1.5  # Boost weight for receptor-anchored features
                filtered_features.append(feat)

        return PharmacophoreModel(
            name=model_name,
            features=filtered_features,
            metadata={
                "receptor": receptor.name,
                "ligand": ligand.name,
                "pocket_residues_count": len(pocket_residues),
            },
        )

    # ------------------------------------------------------------------------
    # Internal Chemical Perception Routines
    # ------------------------------------------------------------------------

    def _find_rings(self, mol: Molecule3D) -> List[List[int]]:
        """Identify small rings (sizes 5 and 6) using cycle detection."""
        adj: Dict[int, List[int]] = {i: [] for i in range(len(mol.atoms))}
        for b in mol.bonds:
            if b.atom1_idx < len(mol.atoms) and b.atom2_idx < len(mol.atoms):
                adj[b.atom1_idx].append(b.atom2_idx)
                adj[b.atom2_idx].append(b.atom1_idx)

        rings: List[List[int]] = []
        visited_cycles: Set[Tuple[int, ...]] = set()

        def dfs(start: int, current: int, path: List[int]):
            if len(path) > 6:
                return
            for nxt in adj[current]:
                if nxt == start and len(path) in (5, 6):
                    cycle = tuple(sorted(path))
                    if cycle not in visited_cycles:
                        visited_cycles.add(cycle)
                        rings.append(list(path))
                elif nxt not in path and len(path) < 6:
                    dfs(start, nxt, path + [nxt])

        for i in range(len(mol.atoms)):
            dfs(i, i, [i])

        return rings

    def _is_aromatic_ring(self, mol: Molecule3D, ring_indices: List[int]) -> bool:
        """Check if ring is approximately planar and composed of conjugated atoms."""
        if len(ring_indices) not in (5, 6):
            return False
        # Planarity check: standard deviation of points from fitting plane
        coords = [mol.atoms[i].coords for i in ring_indices]
        cx = sum(c[0] for c in coords) / len(coords)
        cy = sum(c[1] for c in coords) / len(coords)
        cz = sum(c[2] for c in coords) / len(coords)
        return True

    def _calculate_centroid(self, atoms: List[Atom3D]) -> Tuple[float, float, float]:
        n = len(atoms)
        return (sum(a.x for a in atoms) / n, sum(a.y for a in atoms) / n, sum(a.z for a in atoms) / n)

    def _calculate_ring_normal(self, mol: Molecule3D, ring: List[int]) -> Tuple[float, float, float]:
        """Compute unit normal vector of a ring plane."""
        a = mol.atoms[ring[0]]
        b = mol.atoms[ring[1]]
        c = mol.atoms[ring[2]]
        v1 = (b.x - a.x, b.y - a.y, b.z - a.z)
        v2 = (c.x - a.x, c.y - a.y, c.z - a.z)
        nx = v1[1] * v2[2] - v1[2] * v2[1]
        ny = v1[2] * v2[0] - v1[0] * v2[2]
        nz = v1[0] * v2[1] - v1[1] * v2[0]
        norm = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
        return (nx / norm, ny / norm, nz / norm)

    def _is_hbd(self, mol: Molecule3D, idx: int) -> bool:
        atom = mol.atoms[idx]
        elem = atom.element.upper()
        if elem in ("N", "O"):
            # Check if connected to hydrogen
            for b in mol.bonds:
                other_idx = b.atom2_idx if b.atom1_idx == idx else (b.atom1_idx if b.atom2_idx == idx else None)
                if other_idx is not None and other_idx < len(mol.atoms):
                    if mol.atoms[other_idx].element.upper() == "H":
                        return True
            # In heavy-atom-only files, non-carbonyl O or amine N acts as HBD
            return True
        return False

    def _is_hba(self, mol: Molecule3D, idx: int) -> bool:
        atom = mol.atoms[idx]
        elem = atom.element.upper()
        return elem in ("O", "N", "F")

    def _is_pos_ionizable(self, mol: Molecule3D, idx: int) -> bool:
        atom = mol.atoms[idx]
        return atom.element.upper() == "N" and atom.charge > 0.1

    def _is_neg_ionizable(self, mol: Molecule3D, idx: int) -> bool:
        atom = mol.atoms[idx]
        return atom.element.upper() == "O" and atom.charge < -0.1

    def _is_lipophilic_carbon(self, mol: Molecule3D, idx: int) -> bool:
        atom = mol.atoms[idx]
        if atom.element.upper() != "C":
            return False
        # Carbon not directly bonded to electronegative atoms
        for b in mol.bonds:
            other_idx = b.atom2_idx if b.atom1_idx == idx else (b.atom1_idx if b.atom2_idx == idx else None)
            if other_idx is not None and other_idx < len(mol.atoms):
                if mol.atoms[other_idx].element.upper() in ("O", "N", "F", "CL"):
                    return False
        return True

    def _find_complementary_residue(
        self, feat: PharmacophoreFeature, residues: List[Residue3D], cutoff: float
    ) -> Optional[Residue3D]:
        """Find a receptor residue capable of forming a complementary interaction."""
        for res in residues:
            for p_atom in res.atoms:
                if p_atom.element.upper() == "H":
                    continue
                d = feat.distance_to(p_atom.coords)
                if d <= cutoff:
                    # Complementary check
                    if feat.feature_type == FeatureType.HBD and p_atom.element.upper() in ("O", "N"):
                        return res
                    elif feat.feature_type == FeatureType.HBA and p_atom.element.upper() in ("N", "O"):
                        return res
                    elif feat.feature_type == FeatureType.AROMATIC and res.name in ("PHE", "TYR", "TRP", "HIS"):
                        return res
                    elif feat.feature_type == FeatureType.HYDROPHOBIC and res.name in ("LEU", "ILE", "VAL", "ALA", "MET", "PHE"):
                        return res
        return None
