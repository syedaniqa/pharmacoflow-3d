"""
Unit tests for 3D structural chemistry, coordinate math, and file parsers.
"""

import unittest
from pharmacoflow.core.structures import (
    Atom3D,
    Molecule3D,
    ProteinComplex,
    Residue3D,
    calculate_rmsd,
    kabsch_align,
)


class TestStructures(unittest.TestCase):

    def test_atom3d_distance(self):
        a1 = Atom3D("CA", "C", 0.0, 0.0, 0.0)
        a2 = Atom3D("CB", "C", 3.0, 4.0, 0.0)
        self.assertAlmostEqual(a1.distance_to(a2), 5.0, places=4)

    def test_molecule_centroid(self):
        a1 = Atom3D("C1", "C", 1.0, 2.0, 3.0)
        a2 = Atom3D("C2", "C", 3.0, 4.0, 5.0)
        mol = Molecule3D(name="TestMol", atoms=[a1, a2])
        cx, cy, cz = mol.centroid
        self.assertAlmostEqual(cx, 2.0, places=4)
        self.assertAlmostEqual(cy, 3.0, places=4)
        self.assertAlmostEqual(cz, 4.0, places=4)

    def test_rmsd_identical_coords(self):
        c1 = [(1.0, 2.0, 3.0), (4.0, 5.0, 6.0), (7.0, 8.0, 9.0)]
        self.assertAlmostEqual(calculate_rmsd(c1, c1), 0.0, places=5)

    def test_kabsch_alignment(self):
        target = [(0.0, 0.0, 0.0), (1.0, 0.0, 0.0), (0.0, 1.0, 0.0)]
        # Shifted by +5 in X
        mobile = [(5.0, 0.0, 0.0), (6.0, 0.0, 0.0), (5.0, 1.0, 0.0)]
        aligned, rmsd = kabsch_align(mobile, target)
        self.assertAlmostEqual(rmsd, 0.0, places=4)

    def test_protein_binding_pocket_extraction(self):
        res1 = Residue3D("ALA", 1, "A", [Atom3D("CA", "C", 0.0, 0.0, 0.0)])
        res2 = Residue3D("GLY", 2, "A", [Atom3D("CA", "C", 20.0, 20.0, 20.0)])
        protein = ProteinComplex("TestProt", residues=[res1, res2])
        ligand = Molecule3D("Lig", atoms=[Atom3D("C1", "C", 1.0, 1.0, 1.0)])

        pocket = protein.get_binding_pocket(ligand, cutoff_radius=5.0)
        self.assertEqual(len(pocket), 1)
        self.assertEqual(pocket[0].name, "ALA")


if __name__ == "__main__":
    unittest.main()
